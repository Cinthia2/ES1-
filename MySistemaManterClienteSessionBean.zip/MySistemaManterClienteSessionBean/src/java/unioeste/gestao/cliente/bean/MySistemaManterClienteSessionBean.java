package unioeste.gestao.cliente.bean;

import java.sql.SQLException;
import java.util.Map;
import javax.ejb.Stateful;
import javax.naming.NamingException;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import unioeste.gestao.cliente.manager.UCServicoManterCliente;

@Stateful
public class MySistemaManterClienteSessionBean implements MySistemaManterClienteSessionBeanRemote 
{

    @Override
    public Cliente consultarCliente(String string) throws SQLException 
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.consultarCliente(string);
    }

    @Override
    public Boolean clienteExiste(String string) throws SQLException 
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.clienteExiste(string);
    }

    @Override
    public Cliente cadastrarCliente(Cliente clnt) throws SQLException, NegocioException 
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.cadastrarCliente(clnt);
    }

    /*@Override
    public boolean enderecoExiste(Endereco endrc) throws SQLException
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.enderecoExiste(endrc);
    }*/

    @Override
    public Boolean clienteExiste(String string, Map<String, String> map) throws SQLException 
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.clienteExiste(string, map);
    }

    @Override
    public Cliente procurarClienteByID(int i) throws SQLException
    {
        UCServicoManterCliente cliente = new UCServicoManterCliente();
        return cliente.procurarClienteByID(i);   
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

}
