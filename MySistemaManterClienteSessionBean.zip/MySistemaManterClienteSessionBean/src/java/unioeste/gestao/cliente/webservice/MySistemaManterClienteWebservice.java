package unioeste.gestao.cliente.webservice;

import java.sql.SQLException;
import java.util.Map;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.gestao.cliente.bean.MySistemaManterClienteSessionBeanRemote;
import unioeste.gestao.empresa.cliente.bo.Cliente;


@WebService(serviceName = "MySistemaManterClienteWebservice")
@Stateless()
public class MySistemaManterClienteWebservice {

    @EJB
    private MySistemaManterClienteSessionBeanRemote ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "consultarCliente")
    public Cliente consultarCliente(@WebParam(name = "string") String string) throws SQLException {
        return ejbRef.consultarCliente(string);
    }

    @WebMethod(operationName = "clienteExiste")
    public Boolean clienteExiste(@WebParam(name = "string") String string) throws SQLException {
        return ejbRef.clienteExiste(string);
    }

    @WebMethod(operationName = "cadastrarCliente")
    public Cliente cadastrarCliente(@WebParam(name = "clnt") Cliente clnt) throws SQLException, NegocioException{
        return ejbRef.cadastrarCliente(clnt);
    }

    @WebMethod(operationName = "clienteExiste_1")
    @RequestWrapper(className = "clienteExiste_1")
    @ResponseWrapper(className = "clienteExiste_1Response")
    public Boolean clienteExiste(@WebParam(name = "string") String string, @WebParam(name = "map") Map<String, String> map) throws SQLException {
        return ejbRef.clienteExiste(string, map);
    }

    @WebMethod(operationName = "procurarClienteByID")
    public Cliente procurarClienteByID(@WebParam(name = "i") int i) throws SQLException {
        return ejbRef.procurarClienteByID(i);
    }
    
}
