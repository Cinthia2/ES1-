package unioeste.gestao.empresa.cliente.bo;

import java.io.Serializable;
import unioeste.geral.pessoa.bo.Pessoa;

public class Cliente implements Serializable
{
    private Pessoa dadosCliente;
    private int idCliente;
    private int quatidadeContratos; 

    public Pessoa getDadosCliente() 
    {
        return dadosCliente;
    }

    public void setDadosCliente(Pessoa dadosCliente) 
    {
        this.dadosCliente = dadosCliente;
    }

    public int getIdCliente() 
    {
        return idCliente;
    }

    public void setIdCliente(int idCliente) 
    {
        this.idCliente = idCliente;
    }

    public int getQuatidadeContratos() 
    {
        return quatidadeContratos;
    }

    public void setQuatidadeContratos(int quatidadeContratos) 
    {
        this.quatidadeContratos = quatidadeContratos;
    }
   
}
