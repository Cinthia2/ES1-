package unioeste.apoio.verificacao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Verificacao implements Serializable
{
    public Boolean verificarCEP (String CEP)
    {
        System.out.println("Bool CEP:" + (CEP.length() == 8 && CEP.matches("^[0-9]*$")));
        return (CEP.length() == 8 && CEP.matches("^[0-9]*$"));
    }
    
    public int verificarDados (List <String> dados, Map <String, String> messages)
    {
        int count = 0;
        
        if (this.verificarCaracteresNumericos(dados.get(0)))
            count++;
        else
            messages.put("errornumerocontrato", "Número do contrato contém caracteres inválidos.");
        
        if (this.verificarData(dados.get(1), messages))
            count++;
        else
            messages.put("errordataemissao", "Data de emissão inválida.");
        
        if (this.verificarData(dados.get(2), messages))
            count++;
        else
            messages.put("errordatainicial", "Data inicial inválida.");
        
        if (this.verificarData(dados.get(3), messages))
            count++;
        else
            messages.put("errordatafinal", "Data final inválida.");
        
        if (this.verificarCaracteresNumericos(dados.get(4)))
            count++;
        else
            messages.put("errortipocontrato", "ID do tipo de contrato inválido.");
        
        if (this.verificarValorContrato(Double.valueOf(dados.get(5))))
            count++;
        else
            messages.put("errorvalorcontrato", "Valor de contrato inválido. (Menor que R$ 1,00)");
        
        System.out.println("CONTADOR DE VERIFICAÇÃO: " + count);
        return count;
    }
    
    public Boolean verificarSexo (String sexo, Map <String, String> messages)
    {
        System.out.println("Sexo: " + (sexo.length() == 1 && (sexo.equals("M") || sexo.equals("F") || sexo.equals("m") || sexo.equals("f"))));
        if (!(sexo.length() == 1 && (sexo.equals("M") || sexo.equals("F") || sexo.equals("m") || sexo.equals("f"))))
        {
            messages.put ("errorsexo", "Sexo com tamanho ou caracteres inválidos.");
            return false;
        } 
        return true;
    }
    
    public Boolean verificarSexo (String sexo)
    {
        System.out.println("Sexo: " + (sexo.length() == 1 && (sexo.equals("M") || sexo.equals("F") || sexo.equals("m") || sexo.equals("f"))));
        return sexo.length() == 1 && (sexo.equals("M") || sexo.equals("F") || sexo.equals("m") || sexo.equals("f"));
    }
    
    public Boolean verificarNumLogradouro (String num, Map <String, String> messages)
    {
        System.out.println("Num casa: " + (verificarCaracteresNumericos (num) && (num.length() > 1 && num.length() <= 10)));
        if (!(verificarCaracteresNumericos (num) && (num.length() > 1 && num.length() <= 10)))
        {
            messages.put ("errornum", "Numeração com caracteres inválidos ou maior que 10 casas numéricas.");
            return false;
        }        
        return true;
    }
    
    public Boolean verificarDDD (String ddd, Map <String, String> messages)
    {
        System.out.println("DDD: " + (verificarCaracteresNumericos (ddd) && ddd.length() == 2));
        if (!(verificarCaracteresNumericos (ddd) && ddd.length() == 2))
        {
            messages.put ("errorddd", "DDD com caracteres inválidos ou maior que 2 (dois) dígitos.");
            return false;
        }       
        return true;
    }
    
    public Boolean verificarTelefone (String fone, Map <String, String> messages)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        if (!(verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)))
        {
            messages.put ("errorfone", "Telefone com caracteres inválidos ou maior que 14 (quatorze) dígitos.");
            return false;
        }       
        return true;
    }
    
    public Boolean verificarTelefone (String fone)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        return verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14);
    }    

    public Boolean verificarCaracteresNumericos (String target)
    {
        return target.matches("^[0-9]*$");
    }
    
    public Boolean verificarCPF (String cpf, Map <String, String> messages)
    {
        System.out.println("CPF: " + (verificarCaracteresNumericos (cpf) && cpf.length() == 11));
        if (!(verificarCaracteresNumericos (cpf) && cpf.length() == 11))
        {
            messages.put ("errorcpf", "CPF com caracteres inválidos, maior ou menor que 11 caracteres.");
            return false;
        }
        return true;
    }
    
    public Boolean verificarCPF (String cpf)
    {
        System.out.println("CPF: " + (verificarCaracteresNumericos (cpf) && cpf.length() == 11));
        return verificarCaracteresNumericos (cpf) && cpf.length() == 11;
    }
    
    public Boolean verificarNome (String nome, Map <String, String> messages)
    {
        System.out.println ("Nome: " + (nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)));
        if (!(nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)))
        {
            messages.put("errorname", "Nome com caracteres inválidos e/ou menor que 5 ou maior que 100 caracteres.");
            return false;
        }
        return true;
    }
    
    public Boolean verificarNome (String nome)
    {
        System.out.println ("Nome: " + (nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)));
        return nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100);
    }
    
    public Boolean verificarData (String data, Map <String, String> messages)
    {
        System.out.println("Data: " + (data.length() == 10));
        if (!(data.length() == 10))
        {
            messages.put ("errordata", "Data inválida ou incompátivel com o CPF adicionado.");
            return false;          
        }
        return true;
    }
    
    public Boolean verificarDia (String dia)
    {
        int day = Integer.valueOf(dia);
        return (day > 0 && day < 32);
    }
    
    public Boolean verificarMes (String mes)
    {
        int month = Integer.valueOf(mes);
        return (month > 0 && month < 13);
    }
    
    public Boolean verificarAno (String ano)
    {
        int year = Integer.valueOf(ano);
        return (year > 1950 && year < 2070);
    }
    
    public Boolean verificarTamanhoComplemento (String target, Map <String, String> messages)
    {
        System.out.println("Complemento: " + (target.length() <= 100));
        if (!(target.length() <= 100))
        {
            messages.put ("errorcomplemento", "Complemento com tamanho inválido (mais de 100 caracteres).");
            return false;
        }        
        return true;
    }
    
    public Boolean verificarEmail (String email, Map <String, String> messages)
    {
        System.out.println("Email: " + (email.contains("@") && (email.length() > 5 && email.length() <= 30)));
        if (!(email.contains("@") && (email.length() > 5 && email.length() <= 30)))
        {
            messages.put ("erroremail", "Email inválido ou maior que 30 (trinta) caracteres.");
            return false;
        }
        return true;
    }
    
    public Boolean verificarData (String data)
    {
        if (!(data.length() == 10))
        {
            return false;
        }
        else
        {
            String[] datasplit;
            datasplit = data.split("-");
            
            for (int i = 0; i < 2; i++)
            {
                if (!(verificarCaracteresNumericos(datasplit[i])))
                    return false;
            }
            
            return (verificarDia(datasplit[0]) && verificarMes(datasplit[1]) && verificarAno(datasplit[2]));
        }
    }
    
    public Boolean verificarNumeroContrato(String numero)
    {
        return verificarCaracteresNumericos (numero);
    }
    
    public Boolean validarDatas (String dataInicial, String dataFinal)
    {
        String[] datasplit1, datasplit2;
        datasplit1 = dataInicial.split("-");
        datasplit2 = dataFinal.split("-");
       
        if (Integer.valueOf(datasplit2[2]) < Integer.valueOf(datasplit1[2]))
        {
            return false;
        }
        
        if (Objects.equals(Integer.valueOf(datasplit2[2]), Integer.valueOf(datasplit1[2])))
        {
            if (Integer.valueOf(datasplit2[1]) < Integer.valueOf(datasplit1[1]))
                return false;
        }
        
        if (Objects.equals(Integer.valueOf(datasplit2[2]), Integer.valueOf(datasplit1[2])))
        {
            if (Objects.equals(Integer.valueOf(datasplit2[1]), Integer.valueOf(datasplit1[1])))
            {
                if (Integer.valueOf(datasplit2[0]) < Integer.valueOf(datasplit1[0]))
                    return false;
            }           
        } 
       
        return true;
        
    }
    
    public Boolean verificarValorContrato (double valor)
    {
        return (valor >= 1.0f);
    }    
}
