package unioeste.apoio.exceptions;

import java.io.Serializable;

public class NegocioException extends Exception implements Serializable
{
    
    public NegocioException (String message) 
    {
	super(message);
    }
}
