package unioeste.apoio.BD;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import org.postgresql.ds.PGConnectionPoolDataSource;

public class ConexaoBanco implements Serializable
{ 
    private static Connection connection;
    private static javax.sql.ConnectionPoolDataSource dataSource;

    private static void createConnectionPool()
    {        
        PGConnectionPoolDataSource pool = new PGConnectionPoolDataSource();
        pool.setUrl("jdbc:postgresql://localhost:5432/trabalhoESI4");
        pool.setUser("postgres");
        pool.setPassword("1234");
        dataSource = pool;
    }
    
    public static Connection getConnection() throws SQLException
    {  
        if(dataSource == null)
        {
        createConnectionPool();
        }

        if(connection == null || connection.isClosed())
        {
            //connection = DriverManager.getConnection("jdbc:postgresql://localhost/alura", "postgres", "postgres");            
            connection = dataSource.getPooledConnection().getConnection();
            //connection.setAutoCommit(false);
        }
        return connection;
        
        /*try
        {
            DriverManager.registerDriver(new org.postgresql.Driver());
            return DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalhoESI4", "postgres", "1234");
        } 
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }*/
    }
}
          

