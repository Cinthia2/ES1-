package unioeste.gestao.contrato.manager;

import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import unioeste.gestao.contrato.bean.MySistemaManterContratoSessionBeanRemote;

public class UCMySistemaManterContratoRemote 
{
    MySistemaManterContratoSessionBeanRemote contrato;
    
    public UCMySistemaManterContratoRemote () throws NamingException
    {
        //Properties props = new Properties();
        //props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        //props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
        //props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
        //props.setProperty("java.naming.factory.state", "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
        //props.setProperty("org.omg.CORBA.ORBInitialHost", "127.0.0.1");
        //props.setProperty("org.omg.CORBA.ORBInitialPort", "35320");     
        //Context ic = new InitialContext (props);
        InitialContext ic = new InitialContext ();
        
        contrato = (MySistemaManterContratoSessionBeanRemote) ic.lookup("java:global/MySistemaManterContratoSessionBean/MySistemaManterContratoSessionBean");
    }
    
    public MySistemaManterContratoSessionBeanRemote getSessionBean ()
    {
        return this.contrato;
    } 
}
