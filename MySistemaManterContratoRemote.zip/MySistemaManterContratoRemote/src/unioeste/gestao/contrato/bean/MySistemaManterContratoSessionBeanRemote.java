package unioeste.gestao.contrato.bean;

import java.sql.SQLException;
import javax.ejb.Remote;
import javax.naming.NamingException;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.gestao.empresa.contrato.bo.Contrato;

@Remote
public interface MySistemaManterContratoSessionBeanRemote 
{
    Contrato cadastrarContrato(Contrato contrato) throws SQLException, NegocioException;
    
    Contrato ConsultarContratoPorNumero(String numero) throws SQLException, NegocioException;
    
    Boolean contratoExiste (String numero) throws SQLException;
}
