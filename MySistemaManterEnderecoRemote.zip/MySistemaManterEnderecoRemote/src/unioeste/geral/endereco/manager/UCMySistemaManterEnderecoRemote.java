package unioeste.geral.endereco.manager;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import unioeste.geral.endereco.bean.MySistemaManterEnderecoSessionBeanRemote;

public class UCMySistemaManterEnderecoRemote 
{
    MySistemaManterEnderecoSessionBeanRemote endereco;
    
        public UCMySistemaManterEnderecoRemote () throws NamingException
    {
        //Properties props = new Properties();
        //props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
        //props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
        //props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
        //props.setProperty("java.naming.factory.state", "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
        //props.setProperty("org.omg.CORBA.ORBInitialHost", "127.0.0.1");
        //props.setProperty("org.omg.CORBA.ORBInitialPort", "35320");     
        //Context ic = new InitialContext (props);
        InitialContext ic = new InitialContext ();
        
        endereco = (MySistemaManterEnderecoSessionBeanRemote) ic.lookup("java:global/MySistemaManterEnderecoSessionBean/MySistemaManterEnderecoSessionBean");
    }
    
    public MySistemaManterEnderecoSessionBeanRemote getSessionBean ()
    {
        return this.endereco;
    } 
}
