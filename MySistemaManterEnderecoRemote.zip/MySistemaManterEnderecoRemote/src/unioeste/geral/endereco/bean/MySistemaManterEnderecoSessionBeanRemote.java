package unioeste.geral.endereco.bean;

import java.sql.SQLException;
import javax.ejb.Remote;
import unioeste.geral.endereco.bo.Endereco;

@Remote
public interface MySistemaManterEnderecoSessionBeanRemote 
{
    Endereco getEndereco (String CEP) throws SQLException;
    
    Boolean verificarCEP (String cep);
    
    Endereco getEnderecoByID (int idEndereco) throws SQLException;
}
