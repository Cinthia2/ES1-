package unioeste.geral.endereco.col;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import unioeste.geral.endereco.bo.Bairro;
import unioeste.geral.endereco.bo.Rua;
import unioeste.geral.endereco.dao.DaoBairro;
import unioeste.geral.endereco.dao.DaoRua;

public class ControllerBairro implements Serializable
{
    private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
    }
    
    public Connection getConnection ()
    {
        return this.connection;
    }
    
    public Bairro procurarBairroByID (int id) throws SQLException
    {
        DaoBairro dao = new DaoBairro (connection);
        Bairro bairro;
        
        bairro = dao.getBairroByID (id);
        
        return bairro;
    }
    
}
