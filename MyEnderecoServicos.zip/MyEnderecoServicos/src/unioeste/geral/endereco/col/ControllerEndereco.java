package unioeste.geral.endereco.col;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.dao.DaoEndereco;

public class ControllerEndereco implements Serializable
{
   
    private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
    }
    
    public Connection getConnection ()
    {
        return this.connection;
    }
    
    public Endereco procurarEnderecoByCEP (String CEP) throws SQLException
    {
        DaoEndereco dao = new DaoEndereco(connection);
        Endereco endereco;
        
        endereco = dao.getEnderecoByCEP(CEP);
        
        if (endereco == null)
        {
            System.out.print("CEP não cadastrado");
            return endereco;
        }
        return endereco;
    }
    
    public Endereco procurarEnderecoByID (int ID) throws SQLException
    {
        DaoEndereco dao = new DaoEndereco(connection);
        Endereco endereco;
        
        endereco = dao.getEnderecoByID(ID);
        
        if (endereco == null)
        {
            System.out.print("CEP não cadastrado");
            return endereco;
        }
        return endereco;
    }    
    
}
