package unioeste.geral.endereco.col;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import unioeste.geral.endereco.bo.Estado;
import unioeste.geral.endereco.bo.Rua;
import unioeste.geral.endereco.dao.DaoEstado;
import unioeste.geral.endereco.dao.DaoRua;

public class ControllerEstado implements Serializable
{
    
    private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
    }
    
    public Connection getConnection ()
    {
        return this.connection;
    } 
    
    public Estado procurarEstadoByID (int id) throws SQLException
    {
        DaoEstado dao = new DaoEstado (connection);
        Estado estado;
        
        estado = dao.getEstadoByID (id);
        
        return estado;
    }
    
}
