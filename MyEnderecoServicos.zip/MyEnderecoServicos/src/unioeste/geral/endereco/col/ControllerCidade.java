package unioeste.geral.endereco.col;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import unioeste.geral.endereco.bo.Cidade;
import unioeste.geral.endereco.bo.Rua;
import unioeste.geral.endereco.dao.DaoCidade;
import unioeste.geral.endereco.dao.DaoRua;

public class ControllerCidade implements Serializable
{
    
    private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
    }
    
    public Connection getConnection ()
    {
        return this.connection;
    }
    
    public Cidade procurarCidadeByID (int id) throws SQLException
    {
        DaoCidade dao = new DaoCidade (connection);
        Cidade cidade;
        
        cidade = dao.getCidadeByID (id);

        return cidade;
    }
}
