package unioeste.geral.endereco.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.geral.endereco.bo.Bairro;
import unioeste.geral.endereco.bo.Cidade;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.bo.Estado;
import unioeste.geral.endereco.bo.Rua;

public class DaoEndereco implements Serializable
{
    
    private Connection connection;
    
    public DaoEndereco(Connection connection)
    {
         this.connection = connection;
    }
   
    public Endereco getEnderecoByCEP (String CEP) throws SQLException
            
    {
        
        String sql = "SELECT * FROM endereco WHERE endereco.cep = '" + CEP + "';";
        
        PreparedStatement stmt = connection.prepareStatement(sql);
        
        Endereco endereco = new Endereco ();
        Rua rua = new Rua ();
        Bairro bairro = new Bairro ();
        Cidade cidade = new Cidade ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cidade.setId(rs.getInt("idcidade"));
                endereco.setCidade(cidade);
                rua.setId(rs.getInt("idrua"));
                endereco.setRua(rua);
                bairro.setId(rs.getInt("idbairro"));
                endereco.setBairro(bairro);
                endereco.setId(rs.getInt("idendereco"));
                endereco.setCEP(rs.getString("cep"));
                System.out.println (endereco.getCEP());
            }
        }
        stmt.close();
        if (endereco.getBairro() == null)
        {
            endereco = null;
        }
       
        return endereco;
    }
    
    public Endereco getEnderecoByID (int id) throws SQLException            
    {        
        String sql = "SELECT * FROM endereco WHERE endereco.idendereco = '" + id + "';";
        
        PreparedStatement stmt = connection.prepareStatement(sql);
        
        Endereco endereco = new Endereco ();
        Rua rua = new Rua ();
        Bairro bairro = new Bairro ();
        Cidade cidade = new Cidade ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cidade.setId(rs.getInt("idcidade"));
                endereco.setCidade(cidade);
                rua.setId(rs.getInt("idrua"));
                endereco.setRua(rua);
                bairro.setId(rs.getInt("idbairro"));
                endereco.setBairro(bairro);
                endereco.setId(rs.getInt("idendereco"));
                endereco.setCEP(rs.getString("cep"));
                System.out.println (endereco.getCEP());
            }
        }
        stmt.close();
        if (endereco.getBairro() == null)
        {
            endereco = null;
        }
       
        return endereco;
    }    
    
}
