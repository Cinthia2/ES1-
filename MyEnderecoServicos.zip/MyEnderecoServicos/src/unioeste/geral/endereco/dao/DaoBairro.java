package unioeste.geral.endereco.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import unioeste.geral.endereco.bo.Bairro;

public class DaoBairro implements Serializable
{
    private Connection connection;
    
    public DaoBairro(Connection connection)
    {
         this.connection = connection;
    }
    
    public Bairro getBairroByID (int id) throws SQLException
    {
        String sql = "SELECT * FROM bairro WHERE bairro.idbairro = '" + id + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Bairro bairro = new Bairro ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                bairro.setId(rs.getInt("idbairro"));
                bairro.setNome(rs.getString("nomebairro"));
            }
        }
        
        stmt.close();
    
        return bairro;
    }     
}
