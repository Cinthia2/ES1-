package unioeste.geral.endereco.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.geral.endereco.bo.Bairro;
import unioeste.geral.endereco.bo.Cidade;
import unioeste.geral.endereco.bo.Estado;

public class DaoCidade implements Serializable
{
    private Connection connection;
    
    public DaoCidade(Connection connection)
    {
         this.connection = connection;
    }
    
    public Cidade getCidadeByID (int id) throws SQLException
    {
        String sql = "SELECT * FROM cidade WHERE cidade.idcidade = '" + id + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Cidade cidade = new Cidade ();
        Estado estado = new Estado ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cidade.setId(rs.getInt("idcidade"));
                cidade.setNome(rs.getString("nomecidade"));
                estado.setId(rs.getInt("idestado"));
                cidade.setEstado(estado);
            }
        }
        
        stmt.close();
    
        return cidade;
    }      
    
}
