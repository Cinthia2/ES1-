package unioeste.geral.endereco.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.geral.endereco.bo.Bairro;
import unioeste.geral.endereco.bo.Cidade;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.bo.Rua;

public class DaoRua implements Serializable
{
  
    private Connection connection;
    
    public DaoRua(Connection connection)
    {
         this.connection = connection;
    }
    
    public Rua getRuaByID (int id) throws SQLException
    {
        String sql = "SELECT * FROM rua WHERE rua.idrua = '" + id + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Rua rua = new Rua ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                rua.setId(rs.getInt("idrua"));
                rua.setNome(rs.getString("nomerua"));
            }
        }
        
        stmt.close();
    
        return rua;
    }    
    
}
