package unioeste.geral.endereco.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.geral.endereco.bo.Estado;
import unioeste.geral.endereco.bo.Rua;

public class DaoEstado implements Serializable
{
    
    private Connection connection;
    
    public DaoEstado(Connection connection)
    {
         this.connection = connection;
    }
    
    public Estado getEstadoByID (int id) throws SQLException
    {
        String sql = "SELECT * FROM estado WHERE estado.idestado = '" + id + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Estado estado = new Estado ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                estado.setId(rs.getInt("idestado"));
                estado.setNome(rs.getString("nomeestado"));
                estado.setUF(rs.getString("uf"));
            }
        }
        
        stmt.close();
    
        return estado;
    }     
    
}
