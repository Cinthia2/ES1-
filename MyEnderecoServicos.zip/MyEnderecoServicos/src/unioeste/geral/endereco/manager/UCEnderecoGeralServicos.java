package unioeste.geral.endereco.manager;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.apoio.verificacao.Verificacao;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.col.ControllerBairro;
import unioeste.geral.endereco.col.ControllerCidade;
import unioeste.geral.endereco.col.ControllerEndereco;
import unioeste.geral.endereco.col.ControllerEstado;
import unioeste.geral.endereco.col.ControllerRua;

public class UCEnderecoGeralServicos implements Serializable
{
    
    private Connection conexaoBD;
    
    public void startConexaoBD () throws SQLException
    {
        //ConexaoBanco bd = new ConexaoBanco ();
        conexaoBD = ConexaoBanco.getConnection ();
        
    }
    
    public void closeConexaoBD () throws SQLException
    {
        conexaoBD.close ();
    }
   
    public Boolean verificarCEP (String cep)
    {
        Verificacao verify = new Verificacao ();
        return verify.verificarCEP(cep);
    }
    
    public Endereco getEndereco (String CEP) throws SQLException
    {
        
        this.startConexaoBD();
        
        ControllerEndereco ctrlEndereco = new ControllerEndereco ();
        
        ctrlEndereco.setConnection (conexaoBD);
        
        Endereco endereco;
        
        endereco = ctrlEndereco.procurarEnderecoByCEP(CEP);
        
        if (endereco == null)
        {
            System.out.println ("Endereco não encontrado.");
            this.closeConexaoBD();
            return null;  
        }
        ControllerRua ctrlRua = new ControllerRua();
        ctrlRua.setConnection(conexaoBD);
        endereco.setRua (ctrlRua.procurarRuaByID (endereco.getRua().getId()));
        
        ControllerBairro ctrlBairro = new ControllerBairro();
        ctrlBairro.setConnection(conexaoBD);
        endereco.setBairro (ctrlBairro.procurarBairroByID (endereco.getBairro().getId()));
        
        ControllerCidade ctrlCidade = new ControllerCidade();
        ctrlCidade.setConnection(conexaoBD);
        endereco.setCidade (ctrlCidade.procurarCidadeByID (endereco.getCidade().getId()));
        
        ControllerEstado ctrlEstado = new ControllerEstado ();
        ctrlEstado.setConnection(conexaoBD);
        endereco.getCidade().setEstado(ctrlEstado.procurarEstadoByID (endereco.getCidade().getEstado().getId()));
        
        System.out.println ("Endereco encontrado.");
        
        this.closeConexaoBD();
        return endereco;
    } 
    
    public Endereco getEnderecoByID (int idEndereco) throws SQLException
    {
        
        this.startConexaoBD();
        
        ControllerEndereco ctrlEndereco = new ControllerEndereco ();
        
        ctrlEndereco.setConnection (conexaoBD);
        
        Endereco endereco;
        
        endereco = ctrlEndereco.procurarEnderecoByID(idEndereco);
        
        if (endereco == null)
        {
            System.out.println ("Endereco não encontrado.");
            this.closeConexaoBD();
            return null;  
        }
        ControllerRua ctrlRua = new ControllerRua();
        ctrlRua.setConnection(conexaoBD);
        endereco.setRua (ctrlRua.procurarRuaByID (endereco.getRua().getId()));
        
        ControllerBairro ctrlBairro = new ControllerBairro();
        ctrlBairro.setConnection(conexaoBD);
        endereco.setBairro (ctrlBairro.procurarBairroByID (endereco.getBairro().getId()));
        
        ControllerCidade ctrlCidade = new ControllerCidade();
        ctrlCidade.setConnection(conexaoBD);
        endereco.setCidade (ctrlCidade.procurarCidadeByID (endereco.getCidade().getId()));
        
        ControllerEstado ctrlEstado = new ControllerEstado ();
        ctrlEstado.setConnection(conexaoBD);
        endereco.getCidade().setEstado(ctrlEstado.procurarEstadoByID (endereco.getCidade().getEstado().getId()));
        
        System.out.println ("Endereco encontrado.");
        
        this.closeConexaoBD();
        return endereco;
    }    
    
}
