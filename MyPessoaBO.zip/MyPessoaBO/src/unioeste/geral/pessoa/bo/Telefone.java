package unioeste.geral.pessoa.bo;

import java.io.Serializable;
import java.util.Map;

public class Telefone implements Serializable
{
    private int id;
    private DDD ddd = null;
    private DDI ddi = null;
    private String numero;

    public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }

    public DDD getDdd() 
    {
        return ddd;
    }

    public void setDdd(DDD ddd) 
    {
        this.ddd = ddd;
    }

    public String getNumero() 
    {
        return numero;
    }

    public void setNumero(String numero) 
    {
        this.numero = numero;
    }

    public DDI getDdi() 
    {
        return ddi;
    }

    public void setDdi(DDI ddi) 
    {
        this.ddi = ddi;
    }
 
    public Boolean verificarTelefone (String fone, Map <String, String> messages)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        if (!(verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)))
        {
            messages.put ("errorfone", "Telefone com caracteres inválidos ou maior que 14 (quatorze) dígitos.");
            return false;
        }       
        return true;
    }
    
    public Boolean verificarTelefone (String fone)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        return verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14);
    }  
    
    public Boolean verificarCaracteresNumericos (String target)
    {
        return target.matches("^[0-9]*$");
    }    
    
}
