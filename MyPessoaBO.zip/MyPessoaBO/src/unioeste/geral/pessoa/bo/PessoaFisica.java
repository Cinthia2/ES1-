package unioeste.geral.pessoa.bo;

import java.io.Serializable;

public class PessoaFisica extends Pessoa implements Serializable
{
    
    private String CPF = null;
    private Sexo sexo = null;
    private String dataNascimento = null;
    
    public void setCPF (String cpf)
    {
        this.CPF = cpf;
    }
    
    public String getCPF ()
    {
        return this.CPF;
    }
    
    public void setSexo (Sexo sexo)
    {
        this.sexo = sexo;
    }
    
    public Sexo getSexo ()
    {
        return this.sexo;
    }

    public String getDataNascimento() 
    {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) 
    {
        this.dataNascimento = dataNascimento;
    }
    
    public Boolean ehCpf (String cpfOuCnpj)
    {
        return (verificarCaracteresNumericos (cpfOuCnpj) && cpfOuCnpj.length() == 11);
    }
    
    public Boolean verificarCaracteresNumericos (String target)
    {
        return target.matches("^[0-9]*$");
    }
       
}
