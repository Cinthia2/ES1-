package unioeste.geral.pessoa.bo;

import java.io.Serializable;
import java.util.Map;

public class Email implements Serializable
{
    private int id;
    private String email;

    public int getId() 
    {
        return id;
    }

    public void setId(int id) 
    {
        this.id = id;
    }

    public String getEmail() 
    {
        return email;
    }

    public void setEmail(String email) 
    {
        this.email = email;
    }
     
    public Boolean verificarEmail (String email, Map <String, String> messages)
    {
        System.out.println("Email: " + (email.contains("@") && (email.length() > 5 && email.length() <= 30)));
        if (!(email.contains("@") && (email.length() > 5 && email.length() <= 30)))
        {
            messages.put ("erroremail", "Email inválido ou maior que 30 (trinta) caracteres.");
            return false;
        }
        return true;
    }    
}
