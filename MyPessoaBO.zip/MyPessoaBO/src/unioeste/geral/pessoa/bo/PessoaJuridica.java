package unioeste.geral.pessoa.bo;

import java.io.Serializable;

public class PessoaJuridica extends Pessoa implements Serializable
{
    private String CNPJ = null;
    private String nomeFantasia = null;
    
    public void setCNPJ (String cnpj)
    {
        this.CNPJ = cnpj;
    }
    
    public String getCNPJ ()
    {
        return this.CNPJ;
    }
    
    public void setNomeFantasia (String nome)
    {
        this.nomeFantasia = nome;
    }
    
    public String getNomeFantasia ()
    {
        return this.nomeFantasia;
    }
}
