package unioeste.geral.pessoa.bo;

import java.io.Serializable;

public class DDI implements Serializable
{
    private int idDDI;
    private String DDI;

    public int getIdDDI() 
    {
        return idDDI;
    }

    public void setIdDDI(int idDDI) 
    {
        this.idDDI = idDDI;
    }

    public String getDDI() 
    {
        return DDI;
    }

    public void setDDI(String DDI) 
    {
        this.DDI = DDI;
    }
    
}
