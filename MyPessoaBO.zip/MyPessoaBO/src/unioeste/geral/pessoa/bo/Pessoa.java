package unioeste.geral.pessoa.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import unioeste.geral.endereco.bo.EnderecoEspecifico;

public abstract class Pessoa implements Serializable
{
    private String nome;
    private EnderecoEspecifico endereco = null;
    private List<Email> email = null;
    private List<Telefone> fone = null;
    
    public void setNome (String nome)
    {
        this.nome = nome;
    };
    
    public String getNome ()
    {
        return this.nome;
    }

    public EnderecoEspecifico getEnderecoEspecifico() 
    {
        return endereco;
    }

    public void setEnderecoEspecifico(EnderecoEspecifico endereco) 
    {
        this.endereco = endereco;
    }

    public List<Email> getEmail() 
    {
        return email;
    }

    public void setEmail(List<Email> email) 
    {
        this.email = email;
    }

    public List<Telefone> getFone() 
    {
        return fone;
    }

    public void setFone(List<Telefone> fone) 
    {
        this.fone = fone;
    }
   
    public Boolean verificarCaracteresNumericos (String target)
    {
        return target.matches("^[0-9]*$");
    }
    
    public Boolean verificarTelefone (String fone, Map <String, String> messages)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        if (!(verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)))
        {
            messages.put ("errorfone", "Telefone com caracteres inválidos ou maior que 14 (quatorze) dígitos.");
            return false;
        }       
        return true;
    }
    
    public Boolean verificarTelefone (String fone)
    {
        System.out.println("Fone: " + (verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14)));
        return verificarCaracteresNumericos (fone) && (fone.length() > 6 && fone.length() <= 14);
    }
    
    public Boolean verificarNome (String nome)
    {
        System.out.println ("Nome: " + (nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)));
        return nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100);
    }
    
    public Boolean verificarNome (String nome, Map <String, String> messages)
    {
        System.out.println ("Nome: " + (nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)));
        if (!(nome.matches("^[a-zA-Z]+(([\\'\\,\\.\\- ][a-zA-Z ])?[a-zA-Z]*)*$") && (nome.length() > 5 && nome.length() <= 100)))
        {
            messages.put("errorname", "Nome com caracteres inválidos e/ou menor que 5 ou maior que 100 caracteres.");
            return false;
        }
        return true;
    }
}
