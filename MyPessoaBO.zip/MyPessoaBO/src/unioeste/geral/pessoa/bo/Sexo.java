package unioeste.geral.pessoa.bo;

import java.io.Serializable;

public class Sexo implements Serializable
{
    private int id;
    private String sigla;
    
    public void setId (int id)
    {
        this.id = id;
    }
    
    public int getId ()
    {
        return this.id;
    }
    
    public void setSigla (String sigla)
    {
        this.sigla = sigla;
    }
    
    public String getSigla ()
    {
        return this.sigla;
    }
}
