package unioeste.gestao.cliente.bean;

import java.sql.SQLException;
import java.util.Map;
import javax.ejb.Remote;
import javax.naming.NamingException;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.gestao.empresa.cliente.bo.Cliente;

@Remote
public interface MySistemaManterClienteSessionBeanRemote 
{
    Cliente consultarCliente (String CPFouCNPJ) throws SQLException;
    
    Boolean clienteExiste (String CPF) throws SQLException;
    
    Cliente cadastrarCliente (Cliente cliente) throws SQLException, NegocioException;
    
    //boolean enderecoExiste (Endereco endereco) throws SQLException;
    
    Boolean clienteExiste (String CPF, Map<String, String> messages) throws SQLException;
    
    Cliente procurarClienteByID (int id) throws SQLException;
}
