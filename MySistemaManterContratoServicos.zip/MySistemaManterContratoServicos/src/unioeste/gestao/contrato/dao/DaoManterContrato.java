package unioeste.gestao.contrato.dao;

import java.io.Serializable;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import unioeste.gestao.empresa.contrato.bo.*;


public class DaoManterContrato implements Serializable
{
    private Connection connection;
    
    public DaoManterContrato(Connection connection)
    {
        this.connection = connection;
    }
    
    // se retornar false, id invalido; 
    public boolean verificarContratoById(int id) throws SQLException
    {
        String sql = "SELECT * FROM contrato WHERE id = '" + id+ "';";
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        int id2=0;
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
          while (rs.next())
          {
              id2 = rs.getInt("id");
           }
        }
        stmt.close(); 
         if( id2 == 0 )return false;
        return true;
    }
    
    public int getQuantidadeContratosPeriodo (Contrato contrato) throws SQLException
    {   
        String sql = "SELECT idcontrato FROM contrato WHERE (datainicial BETWEEN '" 
                + contrato.getPeriodo().getDataInicial() + "' "
                + "AND '" + contrato.getPeriodo().getDataFinal() + "') "
                + "OR (datafinal BETWEEN '" + contrato.getPeriodo().getDataInicial() + "' "
                + "AND '" + contrato.getPeriodo().getDataFinal() + "') "
                + "OR (datainicial <= '" + contrato.getPeriodo().getDataInicial() + "' "
                + "AND datafinal >= '" + contrato.getPeriodo().getDataFinal()+ "') "
                + "AND idcliente = " + contrato.getCliente().getIdCliente() + ";";
        
        PreparedStatement stmt;
        
        stmt = connection.prepareStatement (sql);
        
        int quantidadeContratos = 0;
            
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                if (rs.getInt("idcontrato") > 0)
                {
                    quantidadeContratos++;
                }
            }
        }
        
        stmt.close();
        
        return quantidadeContratos;    
    }
    
    public Contrato buscaContratoByNumero (String numero) throws SQLException
    {
        String sql = "SELECT c.idcontrato, c.idcliente, c.idtipocontrato, "
                + "c.numerocontrato, c.valorcontrato, c.descricao, "
                + "c.dataemissao, c.datainicial, c.datafinal, "
                + "t.tipocontrato FROM contrato c LEFT JOIN "
                + "tipocontrato t ON t.idtipocontrato = c.idtipocontrato "
                + "WHERE c.numerocontrato = '" + numero + "';";
        
        PreparedStatement stmt;
        
        stmt = connection.prepareStatement (sql);
        
        Contrato contrato = new Contrato(); 
        Cliente cliente = new Cliente();
        PeriodoContrato periodo = new PeriodoContrato ();
        TipoContrato tipo = new TipoContrato ();
        DateFormat df = new SimpleDateFormat ("dd-MM-yyyy");
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cliente.setIdCliente(rs.getInt("idcliente"));
                contrato.setCliente(cliente);
           
                tipo.setId(rs.getInt ("idtipocontrato"));
                tipo.setNome(rs.getString ("tipocontrato"));
                contrato.setTipoContrato(tipo);
                
                Date d1 = rs.getDate("datainicial");
                Date d2 = rs.getDate("datafinal");
                
                periodo.setDataInicial(df.format(d1));
                periodo.setDataFinal(df.format(d2));
                contrato.setPeriodo(periodo);
           
                contrato.setDataEmissao(rs.getString("dataemissao"));
                contrato.setDescricao(rs.getString("descricao"));
                contrato.setNumeroContrato(rs.getString("numerocontrato"));
                contrato.setIdContrato(rs.getInt("idcontrato"));
                contrato.setValorContrato(rs.getDouble("valorcontrato"));
            }
        }
        
        stmt.close(); 
        
        return contrato;
    }
    
    public Contrato inserirContrato (Contrato contrato) throws SQLException
    {
        String sql = "INSERT INTO contrato (idcliente, "
                + "idtipocontrato, numerocontrato, valorcontrato, descricao, "
                + "dataemissao, datainicial, datafinal) VALUES (" + contrato.getCliente().getIdCliente() 
                + ", " + contrato.getTipoContrato().getId() + ", '" + contrato.getNumeroContrato() 
                + "', " + contrato.getValorContrato() + ", '" + contrato.getDescricao() 
                + "', '" + contrato.getDataEmissao() + "', '" + contrato.getPeriodo().getDataInicial() 
                + "', '" + contrato.getPeriodo().getDataFinal() + "') RETURNING idcontrato;";
        PreparedStatement stmt;

        stmt = connection.prepareStatement (sql);
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                contrato.setIdContrato(rs.getInt("idcontrato"));
            }
        }
        
        stmt.close();
        
        return contrato;
    }
     
    public Boolean validarNumeroContrato(String numero) throws SQLException
    {
        String sql = "SELECT contrato.numerocontrato FROM contrato "
                + "WHERE contrato.numerocontrato = '" + numero + "';";
        
        PreparedStatement stmt;

        stmt = connection.prepareStatement (sql);
        
        String result = "";
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                result = rs.getString("numerocontrato");
                System.out.println("RESULTADO CONTRATO EXISTE: " + result);
            }
        }
        
        stmt.close();
        
        return result.equals(numero);          
    }
}
