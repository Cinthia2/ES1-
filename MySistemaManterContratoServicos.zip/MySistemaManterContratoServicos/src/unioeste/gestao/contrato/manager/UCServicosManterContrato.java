package unioeste.gestao.contrato.manager;

import java.io.Serializable;
import java.sql.Connection;
import unioeste.gestao.contrato.col.ControllerManterContrato;
import java.sql.SQLException;
//import javax.naming.NamingException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.gestao.cliente.manager.UCServicoManterCliente;
import unioeste.gestao.empresa.contrato.bo.*;


public class UCServicosManterContrato implements Serializable
{
    public Connection conexaoBD;
    
    public void startConexaoBD () throws SQLException
    {
        //ConexaoBanco bd = new ConexaoBanco ();
        conexaoBD = ConexaoBanco.getConnection();         
    }
    
    public void closeConexaoBD () throws SQLException
    {
        conexaoBD.close();
    }
    
    public Contrato cadastrarContrato(Contrato contrato) throws SQLException, NegocioException 
    { 

        UCServicoManterCliente servicoCliente = new UCServicoManterCliente();
        
        /*if (contrato.getCliente().getDadosCliente() instanceof PessoaFisica)
        {
            System.out.println("Pessoa fisica IN");
            PessoaFisica fis = (PessoaFisica)contrato.getCliente().getDadosCliente();
            if (!servicoCliente.clienteExisteByCPF(fis.getCPF()))
            {
                throw new NegocioException ("Nenhum cliente cadastrado com este CPF.");
            }
        }
        else
        {
            if (contrato.getCliente().getDadosCliente() instanceof PessoaJuridica)
            {
                System.out.println("Pessoa juridica IN");
                PessoaJuridica jur = (PessoaJuridica)contrato.getCliente().getDadosCliente();
                
                if (!servicoCliente.clienteExisteByCNPJ(jur.getCNPJ()))
                {
                    throw new NegocioException ("Nenhum cliente cadastrado com este CNPJ.");
                }               
            }
            else
            {
                throw new NegocioException ("Não foi possível distinguir entre pessoa física e juridica.");
            }
        }*/
        
        if (!contrato.verificarNumeroContrato(contrato.getNumeroContrato()))
        {
            throw new NegocioException ("Contrato contém caracteres inválidos.");
        }
        
        if (!contrato.verificarData(contrato.getDataEmissao()))
        {
            throw new NegocioException ("Valores de dia, mês ou ano inválido(s).");
        }
        
        if (!contrato.verificarData(contrato.getPeriodo().getDataFinal()))
        {
            throw new NegocioException ("Valores de dia, mês ou ano inválido(s).");
        }
        
        if (!contrato.verificarData(contrato.getPeriodo().getDataInicial()))
        {
            throw new NegocioException ("Valores de dia, mês ou ano inválido(s).");
        }
        
        if (!contrato.validarDatas(contrato.getPeriodo().getDataInicial(), contrato.getPeriodo().getDataFinal()))
        {
            throw new NegocioException ("Data final acontece antes da data inicial.");
        }
        
        if (!contrato.verificarValorContrato (contrato.getValorContrato()))
        {
            throw new NegocioException ("Valor do contrato deve ser superior à R$ 1,00.");
        }
        
        if (!verificarContratos(contrato))
        {
            throw new NegocioException ("Limite de contratos para um mesmo período atingido.");
        }
        
        this.startConexaoBD();
        
        ControllerManterContrato controllerContrato = new ControllerManterContrato();
        controllerContrato.setConnection(conexaoBD);
        
        Contrato contratoComID = controllerContrato.inserirContrato(contrato);
        
        this.closeConexaoBD();
        
        return contratoComID;
    }
    
    public Contrato ConsultarContratoPorNumero(String numero) throws SQLException, NegocioException
    { 
        Contrato contratoVerificacao = new Contrato ();
        
        if (!(contratoVerificacao.verificarNumeroContrato (numero)))
        {
            throw new NegocioException ("Contrato contém caracteres inválidos.");
        }
        
        if (!this.contratoExiste (numero))
        {
            throw new NegocioException("Nenhum contrato com este número cadastrado em nosso banco.");
        }
        
        this.startConexaoBD();
        
        ControllerManterContrato controllerContrato = new ControllerManterContrato(); 
        controllerContrato.setConnection(conexaoBD);
        
        Contrato contrato = controllerContrato.buscarContratoByNumero(numero);
        
        this.closeConexaoBD();
        
        return contrato;
    }  
    
    public Boolean contratoExiste (String numero) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterContrato controllerContrato = new ControllerManterContrato(); 
        controllerContrato.setConnection(conexaoBD);
        
        Boolean result = controllerContrato.validarNumeroContrato (numero); 
        
        this.closeConexaoBD();
        
        return result;
    }
    
    public Boolean verificarContratos (Contrato contrato) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterContrato controllerContrato = new ControllerManterContrato();
        
        controllerContrato.setConnection(conexaoBD);
        
        int resultado = controllerContrato.getQuantidadeContratosPeriodo(contrato);
                
        this.closeConexaoBD();        
        
        return (resultado < 3);
    }
    
}
