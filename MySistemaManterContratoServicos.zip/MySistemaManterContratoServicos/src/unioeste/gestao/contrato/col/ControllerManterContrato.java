package unioeste.gestao.contrato.col;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import unioeste.gestao.empresa.contrato.bo.Contrato;
import unioeste.gestao.contrato.dao.DaoManterContrato;

public class ControllerManterContrato implements Serializable
{
private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
          
    }
    
    public int getQuantidadeContratosPeriodo(Contrato contrato) throws SQLException
    {
       DaoManterContrato dao = new DaoManterContrato(this.connection);
       
       return dao.getQuantidadeContratosPeriodo(contrato);
    }
    
    public Contrato buscarContratoByNumero( String numero) throws SQLException
    { 
        DaoManterContrato dao = new DaoManterContrato(this.connection);
        
        return dao.buscaContratoByNumero(numero);
    }
    
    public Contrato inserirContrato(Contrato contrato) throws SQLException
    { 
        DaoManterContrato dao = new DaoManterContrato(this.connection); 

        return dao.inserirContrato(contrato);
    }      

    public Boolean validarNumeroContrato (String numero) throws SQLException
    {
        DaoManterContrato dao = new DaoManterContrato (this.connection);
        
        return dao.validarNumeroContrato(numero);
    }
}
