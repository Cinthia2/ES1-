package unioeste.geral.endereco.teste;


import java.sql.SQLException;
import javax.naming.NamingException;
import unioeste.geral.endereco.webservice.Endereco;
import unioeste.geral.endereco.webservice.SQLException_Exception;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author frafr
 */
public class MySistemaManterEnderecoTeste 
{
    public static void main(String[] args) throws SQLException, NamingException, SQLException_Exception
    {
        String CEP = "85851020";
        
       // UCMySistemaManterEnderecoRemote serviceEndereco = new UCMySistemaManterEnderecoRemote ();
        
        Endereco end; 
    
        if ((end = getEndereco(CEP)) != null)
        {
            System.out.println(end.getCidade().getNome());
            System.out.println(end.getBairro().getNome());
            System.out.println(end.getRua().getNome());
            System.out.println(end.getCidade().getEstado().getNome());
        } 
    }
    
    private static Endereco getEndereco(java.lang.String string) throws SQLException_Exception 
    {
        unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice_Service service = new unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice_Service();
        unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice port = service.getMySistemaManterEnderecoWebservicePort();
        return port.getEndereco(string);
    }
}