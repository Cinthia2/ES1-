package poolparty;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import rrrr.Database;

public class PoolParty 
{

    public static void main(String[] args) throws SQLException 
    {
        Connection conn = Database.getConnection();
        String sql = "SELECT * FROM rua WHERE rua.idrua = '1';";
        
        PreparedStatement stmt;
        stmt = conn.prepareStatement (sql);
        
        String rua = "";
        int id = 0;
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                id = rs.getInt("idrua");
                rua = rs.getString("nomerua");   
            }
        }
        
        stmt.close();
        conn.close();
        System.out.println(" Rua: " + rua + " id: " + id);
    }   
}
