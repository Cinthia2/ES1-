
import unioeste.geral.endereco.webservice.Endereco;
import unioeste.gestao.contrato.webservice.Contrato;
import unioeste.gestao.contrato.webservice.NegocioException_Exception;
import unioeste.gestao.contrato.webservice.SQLException_Exception;


public class aaaa 
{
    public static void main(String[] args) throws SQLException_Exception, NegocioException_Exception, unioeste.geral.endereco.webservice.SQLException_Exception
    {
        Contrato contrato;
        try
        {
           contrato = consultarContratoPorNumero ("156023457895274152424000001"); 
        
            System.out.println("------------------------------------------------------------------------");
            System.out.println("Número: " + contrato.getNumeroContrato());
            System.out.println("Data emissão: " + contrato.getDataEmissao());
            System.out.println("Tipo contrato: " + contrato.getTipoContrato().getNome());
            System.out.println("Início: " + contrato.getPeriodo().getDataInicial() 
                    + " Fim: " + contrato.getPeriodo().getDataFinal());
            System.out.println("Descrição: " + contrato.getDescricao());
            System.out.println("Valor: R$ " + contrato.getValorContrato());
            System.out.println("------------------------------------------------------------------------");          
        }
        catch (NegocioException_Exception e)
        {
            System.out.println("Erro: " + e.getMessage());
        }
        
        System.out.println("CONTRATO EXISTE:  " + contratoExiste("123456"));
        
        String CEP = "85851020";
        
       // UCMySistemaManterEnderecoRemote serviceEndereco = new UCMySistemaManterEnderecoRemote ();
        
        Endereco end; 
    
        if ((end = getEndereco(CEP)) != null)
        {
            System.out.println(end.getCidade().getNome());
            System.out.println(end.getBairro().getNome());
            System.out.println(end.getRua().getNome());
            System.out.println(end.getCidade().getEstado().getNome());
        }
           
    }

    private static Contrato consultarContratoPorNumero(java.lang.String numero) throws NegocioException_Exception, SQLException_Exception {
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service service = new unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.consultarContratoPorNumero(numero);
    }

    private static Contrato cadastrarContrato(unioeste.gestao.contrato.webservice.Contrato contrato) throws SQLException_Exception, NegocioException_Exception {
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service service = new unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.cadastrarContrato(contrato);
    }

    private static Boolean contratoExiste(java.lang.String string) throws SQLException_Exception {
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service service = new unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.contratoExiste(string);
    }

    private static Endereco getEndereco(java.lang.String string) throws unioeste.geral.endereco.webservice.SQLException_Exception {
        unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice_Service service = new unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice_Service();
        unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice port = service.getMySistemaManterEnderecoWebservicePort();
        return port.getEndereco(string);
    }
    
}
