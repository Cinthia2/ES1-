package unioeste.gestao.contrato.webservice;

import java.sql.SQLException;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.gestao.contrato.bean.MySistemaManterContratoSessionBeanRemote;
import unioeste.gestao.empresa.contrato.bo.Contrato;

@WebService(serviceName = "MySistemaManterContratoWebservice")
@Stateless()
public class MySistemaManterContratoWebservice 
{

    @EJB
    private MySistemaManterContratoSessionBeanRemote ejbRef;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "cadastrarContrato")
    public Contrato cadastrarContrato(@WebParam(name = "contrato") Contrato contrato) throws SQLException, NegocioException {
        return ejbRef.cadastrarContrato(contrato);
    }

    @WebMethod(operationName = "ConsultarContratoPorNumero")
    public Contrato ConsultarContratoPorNumero(@WebParam(name = "numero") String numero) throws SQLException, NegocioException {
        return ejbRef.ConsultarContratoPorNumero(numero);
    }
    
    @WebMethod(operationName = "contratoExiste")
    public Boolean contratoExiste(@WebParam(name = "string") String string) throws SQLException 
    {
        return ejbRef.contratoExiste(string);
    }
    
}
