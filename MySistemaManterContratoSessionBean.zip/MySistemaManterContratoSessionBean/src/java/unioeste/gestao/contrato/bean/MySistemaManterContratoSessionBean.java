package unioeste.gestao.contrato.bean;

import java.sql.SQLException;
import javax.ejb.Stateful;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.gestao.contrato.manager.UCServicosManterContrato;
import unioeste.gestao.empresa.contrato.bo.Contrato;

@Stateful
public class MySistemaManterContratoSessionBean implements MySistemaManterContratoSessionBeanRemote 
{
    @Override
    public Contrato cadastrarContrato(Contrato contrato) throws SQLException, NegocioException 
    {
        UCServicosManterContrato cont = new UCServicosManterContrato ();
        return cont.cadastrarContrato(contrato);
    }

    @Override
    public Contrato ConsultarContratoPorNumero(String numero) throws SQLException, NegocioException 
    {
        UCServicosManterContrato cont = new UCServicosManterContrato ();
        return cont.ConsultarContratoPorNumero(numero);
    }

    @Override
    public Boolean contratoExiste(String string) throws SQLException 
    {
        UCServicosManterContrato cont = new UCServicosManterContrato ();
        return cont.contratoExiste(string);
    }
}
