package unioeste.geral.endereco.bo;

import java.io.Serializable;
import java.util.Map;

public class EnderecoEspecifico implements Serializable
{
    private Endereco endereco = null;
    private String numero;
    private String complemento;

    public Endereco getEndereco() 
    {
        return endereco;
    }

    public void setEndereco(Endereco endereco) 
    {
        this.endereco = endereco;
    }

    public String getNumero() 
    {
        return numero;
    }

    public void setNumero(String numero) 
    {
        this.numero = numero;
    }

    public String getComplemento() 
    {
        return complemento;
    }

    public void setComplemento(String complemento) 
    {
        this.complemento = complemento;
    }
    
    public Boolean verificarNumLogradouro (String num, Map <String, String> messages)
    {
        System.out.println("Num casa: " + (verificarCaracteresNumericos (num) && (num.length() > 1 && num.length() <= 10)));
        if (!(verificarCaracteresNumericos (num) && (num.length() > 1 && num.length() <= 10)))
        {
            messages.put ("errornum", "Numeração com caracteres inválidos ou maior que 10 casas numéricas.");
            return false;
        }        
        return true;
    }
    
    public Boolean verificarCaracteresNumericos (String target)
    {
        return target.matches("^[0-9]*$");
    }
    
    public Boolean verificarTamanhoComplemento (String target, Map <String, String> messages)
    {
        System.out.println("Complemento: " + (target.length() <= 100));
        if (!(target.length() <= 100))
        {
            messages.put ("errorcomplemento", "Complemento com tamanho inválido (mais de 100 caracteres).");
            return false;
        }        
        return true;
    }
}
