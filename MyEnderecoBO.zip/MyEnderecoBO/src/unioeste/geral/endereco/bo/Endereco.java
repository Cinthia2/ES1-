package unioeste.geral.endereco.bo;

import java.io.Serializable;

public class Endereco implements Serializable
{
    private int id;
    private String CEP;
    private Rua rua = null;
    private Bairro bairro = null;
    private Cidade cidade = null;
    
    public void setId (int id)
    {
        this.id = id;
    }
    
    public int getId ()
    {
        return this.id;
    }
    
    public void setCEP (String cep)
    {
        this.CEP = cep;
    }
    
    public String getCEP ()
    {
        return this.CEP;
    }
    
    public void setRua (Rua rua)
    {
        this.rua = rua;
    }
    
    public Rua getRua ()
    {
        return this.rua;
    }
    
    public void setBairro (Bairro bairro)
    {
        this.bairro = bairro;
    }
    
    public Bairro getBairro ()
    {
        return this.bairro;
    }
    
    public void setCidade (Cidade cidade)
    {
        this.cidade = cidade;
    }
    
    public Cidade getCidade ()
    {
        return this.cidade;
    }
    
    public Boolean verificarCEP (String CEP)
    {
        System.out.println("Bool CEP:" + (CEP.length() == 8 && CEP.matches("^[0-9]*$")));
        return (CEP.length() == 8 && CEP.matches("^[0-9]*$"));
    }
}
