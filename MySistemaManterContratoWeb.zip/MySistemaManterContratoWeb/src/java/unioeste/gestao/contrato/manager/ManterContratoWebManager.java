package unioeste.gestao.contrato.manager;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.apoio.verificacao.Verificacao;
import unioeste.geral.endereco.webservice.Endereco;
import unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice_Service;
import unioeste.geral.pessoa.bo.PessoaFisica;
import unioeste.geral.pessoa.bo.PessoaJuridica;
import unioeste.gestao.cliente.manager.UCMySistemaManterClienteRemote;
import unioeste.gestao.contrato.webservice.Contrato;
import unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice_Service;
import unioeste.gestao.contrato.webservice.NegocioException_Exception;
import unioeste.gestao.contrato.webservice.PeriodoContrato;
import unioeste.gestao.contrato.webservice.SQLException_Exception;
import unioeste.gestao.contrato.webservice.TipoContrato;
import unioeste.gestao.contrato.webservice.Cliente;

public class ManterContratoWebManager
{

    //@WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/MySistemaManterEnderecoWebservice/MySistemaManterEnderecoWebservice.wsdl")
    //private MySistemaManterEnderecoWebservice_Service service_2;

    //@WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/MySistemaManterContratoWebservice/MySistemaManterContratoWebservice.wsdl")
    //private MySistemaManterContratoWebservice_Service service;
    
    public void processarContrato (HttpServletRequest request,
            HttpServletResponse response, Map <String, String> messages, unioeste.gestao.empresa.cliente.bo.Cliente cliente) 
            throws ServletException, IOException, SQLException, ParseException, NegocioException, SQLException_Exception
    {
        System.out.println("Coletando dados contrato.");
        Contrato contrato = this.coletarDados (messages, request, response);
        
        if (contrato != null)
        {
            System.out.println("Pegando o cliente.");
            unioeste.gestao.contrato.webservice.Cliente cli = new unioeste.gestao.contrato.webservice.Cliente();
            
            cli.setIdCliente(cliente.getIdCliente());
            contrato.setCliente(cli);
            System.out.println("Cadastrando novo contrato.");
                      
            try
            {
                //adicionarDadosPaciente (paciente);
                contrato = cadastrarContrato (contrato);
                
                messages.put("success", "Paciente adicionado com sucesso!");  
            } 
            catch (NegocioException_Exception ex) 
            {
                messages.put("cadastroerro", ex.getMessage());
                Logger.getLogger(ManterContratoWebManager.class.getName()).log(Level.SEVERE, null, ex);
            }         
        }
    }
    
    public unioeste.gestao.empresa.cliente.bo.Cliente findCliente (HttpServletRequest request,
            HttpServletResponse response, Map <String, String> messages) 
            throws ServletException, IOException, SQLException, NamingException, 
            SQLException_Exception, unioeste.geral.endereco.webservice.SQLException_Exception
    {
        String cpfcnpj = null;

        cpfcnpj = request.getParameter("cpfcnpj"); 
        System.out.println(cpfcnpj);

        return this.getCliente(messages, cpfcnpj);
                
    }
    
    public unioeste.gestao.empresa.cliente.bo.Cliente getCliente (Map <String, String> messages, String cpfcnpj) throws SQLException, NamingException, SQLException_Exception, unioeste.geral.endereco.webservice.SQLException_Exception
    {
        UCMySistemaManterClienteRemote cliRemote = new UCMySistemaManterClienteRemote();
        
        System.out.println ("GET CLIENTE");
        unioeste.gestao.empresa.cliente.bo.Cliente cli;
        int idEndereco = 0; 
        
        if ((cli = cliRemote.getSessionBean().consultarCliente(cpfcnpj)) != null)
        {    
            System.out.println ("PEGOU CLIENTE");
            if (cli.getDadosCliente() instanceof PessoaFisica)
            {
                PessoaFisica fis = (PessoaFisica)cli.getDadosCliente();

                messages.put("sexo", fis.getSexo().getSigla());
                messages.put("cpfcnpj", fis.getCPF());
                messages.put("data", fis.getDataNascimento());
                messages.put("namefan", "-");
                
                messages.put("name", fis.getNome());
                messages.put("complemento", fis.getEnderecoEspecifico().getComplemento());
                messages.put("num", fis.getEnderecoEspecifico().getNumero());
                messages.put("email", fis.getEmail().get(0).getEmail());
                messages.put("fone", fis.getFone().get(0).getNumero());
                messages.put("ddd", fis.getFone().get(0).getDdd().getNumero());
                messages.put("ddi", fis.getFone().get(0).getDdi().getDDI());
                System.out.println(fis.getEnderecoEspecifico().getEndereco().getId());
                idEndereco = fis.getEnderecoEspecifico().getEndereco().getId();
                
            }
            else
            {
                PessoaJuridica jur = (PessoaJuridica)cli.getDadosCliente();
                messages.put("namefan", jur.getCNPJ());
                messages.put("cpfcnpj", jur.getNomeFantasia());
                messages.put("sexo", "-");
                messages.put("data", "-");
                
                messages.put("name", jur.getNome());
                messages.put("complemento", jur.getEnderecoEspecifico().getComplemento());
                messages.put("num", jur.getEnderecoEspecifico().getNumero());
                messages.put("email", jur.getEmail().get(0).getEmail());
                messages.put("fone", jur.getFone().get(0).getNumero());
                messages.put("ddd", jur.getFone().get(0).getDdd().getNumero());
                messages.put("ddi", jur.getFone().get(0).getDdi().getDDI());
                
                idEndereco = jur.getEnderecoEspecifico().getEndereco().getId();
            }
                Endereco end = getEnderecoByID(idEndereco);

                messages.put("cep", end.getCEP());
                messages.put("rua", end.getRua().getNome());
                messages.put("bairro", end.getBairro().getNome());
                messages.put("cidade", end.getCidade().getNome());
                messages.put("estado", end.getCidade().getEstado().getNome());
                messages.put("sigla", end.getCidade().getEstado().getUF());
            
            return cli;
        }
        else
        {
            messages.put("errorcpfcnpj", "CPF/CNPJ com caracteres inválidos.");
            messages.put("errorcliente", "Não foi possível encontrar este cliente.");
        }       
        return null;
    }
    
    public Contrato coletarDados (Map <String, String> messages, HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException, SQLException
    {
        System.out.println("Coletando dados.");
        
        List <String> dados = new ArrayList <> ();
        
        String numerocontrato = request.getParameter("numerocontrato");
        System.out.println("Num contratro: " + numerocontrato);
        dados.add(numerocontrato);
        
        String dataemissao = request.getParameter("dataemissao");
        dados.add(dataemissao);
        
        String datainicial = request.getParameter("datainicial");
        dados.add(datainicial);
        
        String datafinal = request.getParameter("datafinal");
        dados.add(datafinal);
        
        String tipocontrato = request.getParameter("tipocontrato");
        dados.add(tipocontrato);

        String valorcontrato = request.getParameter("valorcontrato");
        dados.add(valorcontrato);
        
        String descricaocontrato = request.getParameter("descricaocontrato");
        dados.add(descricaocontrato);
        
        Verificacao verify = new Verificacao ();
        
        if (verify.verificarDados (dados, messages) == 6)
        {
            try 
            {
                System.out.println("MILEY ENTRANDO.");
                if (!contratoExiste(numerocontrato))
                {
                    System.out.println("MILEY ENTRANDO 2.");
                    return montarObjetoContrato (dados);
                }
                else
                {
                    messages.put("errornumerocontrato", "Já existe contrato com este número.");
                }
            } 
            catch (SQLException_Exception ex) 
            {
                messages.put("errornumerocontrato", ex.getMessage());
                Logger.getLogger(ManterContratoWebManager.class.getName()).log(Level.SEVERE, null, ex);
            }           
        }
        else
        {
            messages.put ("cadastroerro", "Número de contrato já cadastrado no sistema.");
        }
        return null; 
    }
    
    public Contrato montarObjetoContrato (List <String> dados)
    {
        System.out.println("Montando objeto.");
        Contrato contrato = new Contrato ();
        TipoContrato tipo = new TipoContrato ();
        PeriodoContrato periodo = new PeriodoContrato ();
        
        contrato.setNumeroContrato(dados.get(0));
        contrato.setDataEmissao(dados.get(1));
        
        periodo.setDataInicial(dados.get(2));
        periodo.setDataFinal(dados.get(3));
        contrato.setPeriodo(periodo);
        
        tipo.setId(Integer.valueOf(dados.get(4)));
        contrato.setTipoContrato(tipo);
        
        contrato.setValorContrato(Double.valueOf(dados.get(5)));
        contrato.setDescricao(dados.get(6));
        
        return contrato;
    }
    
    public void findContrato (HttpServletRequest request, HttpServletResponse 
            response) throws ServletException, IOException, SQLException, NamingException, SQLException_Exception, NegocioException_Exception, unioeste.geral.endereco.webservice.SQLException_Exception
    {
        Map<String, String> messages;
        messages = new HashMap<> ();
        String contratoNum = "";
        Contrato contrato;
        Cliente cliente;
        Endereco endereco;
        
        request.setAttribute("messages", messages);
        
        System.out.println("aqui");
        if (request.getParameter("procurarcontrato") != null)
        {
            contratoNum = request.getParameter("numerocontrato");
            System.out.println("EITA CONTATO NUM: " + contratoNum);
            if (contratoExiste(contratoNum))
            {
                contrato = consultarContratoPorNumero(contratoNum);
                UCMySistemaManterClienteRemote cliRemote = new UCMySistemaManterClienteRemote();
                unioeste.gestao.empresa.cliente.bo.Cliente cli = cliRemote.getSessionBean().procurarClienteByID(contrato.getCliente().getIdCliente());
                System.out.println("aqui sempre");
                System.out.println(cli.getDadosCliente().getEnderecoEspecifico().getEndereco().getId());
                unioeste.geral.endereco.webservice.Endereco end = getEnderecoByID (cli.getDadosCliente().getEnderecoEspecifico().getEndereco().getId());
                formatarDados(contrato, cli, end, messages);
            }
            else
            {
                messages.put("errornumerocontrato", "Número de contrato inválido ou não cadastrado.");
            }
        }
        //request.setAttribute("messages", messages);
        request.getRequestDispatcher("/procurar_contrato.jsp").forward(request, response);
    }

    public void formatarDados (Contrato contrato, unioeste.gestao.empresa.cliente.bo.Cliente cli, unioeste.geral.endereco.webservice.Endereco end, Map <String, String> messages)
    {
        messages.put("numerocontrato", contrato.getNumeroContrato());
        messages.put("dataemi", contrato.getDataEmissao());
        messages.put("dataini", contrato.getPeriodo().getDataInicial());
        messages.put("datafim", contrato.getPeriodo().getDataFinal());
        messages.put("tipocontrato", contrato.getTipoContrato().getNome());
        messages.put("valorcontrato", String.valueOf(contrato.getValorContrato()));
        messages.put("descricao", contrato.getDescricao());

        if (cli.getDadosCliente() instanceof unioeste.geral.pessoa.bo.PessoaFisica)
        {
            unioeste.geral.pessoa.bo.PessoaFisica fis = (unioeste.geral.pessoa.bo.PessoaFisica)cli.getDadosCliente();
            
            messages.put("nome", fis.getNome());
            messages.put("nomef", "-");
            messages.put("sexo", fis.getSexo().getSigla());
            messages.put("data", fis.getDataNascimento());
            messages.put("cpfcnpj", fis.getCPF());
        }
        else
        {
            unioeste.geral.pessoa.bo.PessoaJuridica jur = (unioeste.geral.pessoa.bo.PessoaJuridica)cli.getDadosCliente();
            
            messages.put("nome", jur.getNome());
            messages.put("nomef", jur.getNomeFantasia());
            messages.put("sexo", "-");
            messages.put("data", "-");
            messages.put("cpfcnpj", jur.getCNPJ());
        }
        messages.put("num", cli.getDadosCliente().getEnderecoEspecifico().getNumero());
        messages.put("complemento", cli.getDadosCliente().getEnderecoEspecifico().getComplemento());
        messages.put("cep", end.getCEP());
        messages.put("rua", end.getRua().getNome());
        messages.put("bairro", end.getBairro().getNome());
        messages.put("cidade", end.getCidade().getNome());
        messages.put("estado", end.getCidade().getEstado().getNome());
        messages.put("sigla", end.getCidade().getEstado().getUF());
        messages.put("ddi", cli.getDadosCliente().getFone().get(0).getDdi().getDDI());
        messages.put("ddd", cli.getDadosCliente().getFone().get(0).getDdd().getNumero());
        messages.put("fone", cli.getDadosCliente().getFone().get(0).getNumero());
        messages.put("email", cli.getDadosCliente().getEmail().get(0).getEmail());

    }

    private Contrato cadastrarContrato(unioeste.gestao.contrato.webservice.Contrato contrato) throws SQLException_Exception, NegocioException_Exception, unioeste.gestao.contrato.webservice.NegocioException_Exception, unioeste.gestao.contrato.webservice.SQLException_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        MySistemaManterContratoWebservice_Service service = new MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.cadastrarContrato(contrato);
    }

    private Contrato consultarContratoPorNumero(java.lang.String numero) throws SQLException_Exception, NegocioException_Exception, unioeste.gestao.contrato.webservice.NegocioException_Exception, unioeste.gestao.contrato.webservice.SQLException_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        MySistemaManterContratoWebservice_Service service = new MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.consultarContratoPorNumero(numero);
    }

    private Boolean contratoExiste(java.lang.String string) throws SQLException_Exception, unioeste.gestao.contrato.webservice.SQLException_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        MySistemaManterContratoWebservice_Service service = new MySistemaManterContratoWebservice_Service();
        unioeste.gestao.contrato.webservice.MySistemaManterContratoWebservice port = service.getMySistemaManterContratoWebservicePort();
        return port.contratoExiste(string);
    }

    private Endereco getEnderecoByID(int _int) throws unioeste.geral.endereco.webservice.SQLException_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        MySistemaManterEnderecoWebservice_Service service_2 = new MySistemaManterEnderecoWebservice_Service();
        unioeste.geral.endereco.webservice.MySistemaManterEnderecoWebservice port = service_2.getMySistemaManterEnderecoWebservicePort();
        return port.getEnderecoByID(_int);
    }
}    