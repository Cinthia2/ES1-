package unioeste.gestao.contrato.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.gestao.contrato.manager.ManterContratoWebManager;
import unioeste.gestao.contrato.webservice.NegocioException_Exception;
import unioeste.gestao.contrato.webservice.SQLException_Exception;
import unioeste.gestao.empresa.cliente.bo.Cliente;


public class ManterContratoServlet extends HttpServlet 
{

    private String pageLoaded = null;
    private int idCliente = -1;
    private Cliente cliente = null;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String actionPath = request.getServletPath();
        System.out.println(actionPath);

        switch (actionPath) 
        {
            case "/cadastrar_contrato":
                pageLoaded = "add";
                System.out.println("TENTANDO MUITO");
                request.getRequestDispatcher("/cadastrar_contrato.jsp").forward(request, response);
                break;
            case "/procurar_contrato":
                pageLoaded = "find";
                System.out.println("TENTANDO MUITO");
                request.getRequestDispatcher("/procurar_contrato.jsp").forward(request, response);
                break;
            default:
                System.out.println("TENTANDO");
                break;
        } 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        switch (pageLoaded)
        {
            // CADASTRA CONTRATO
            case "add":
                {
                    Map<String, String> messages = new HashMap<> ();
                    request.setAttribute("messages", messages);

                    if ((request.getParameter("enviardados") != null) && cliente != null)
                    {
                        try 
                        {
                            //System.out.println ("TENTANDO ENVIAR");
                            ManterContratoWebManager webManager = new ManterContratoWebManager();
                            
                            webManager.processarContrato (request, response, messages, cliente);
                            
                            cliente = null;
                            
                        } 
                        catch (NegocioException | SQLException | ParseException | SQLException_Exception ex) 
                        {
                            Logger.getLogger(ManterContratoServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    // PROCURA INFO DO CLIENTE
                    if (request.getParameter("procurarcliente") != null)
                    {
                        try 
                        {
                            ManterContratoWebManager webManager = new ManterContratoWebManager();
                            
                            cliente = webManager.findCliente (request, response, messages);
                            
                        } catch (SQLException | NamingException | SQLException_Exception | unioeste.geral.endereco.webservice.SQLException_Exception ex) 
                        {
                            Logger.getLogger(ManterContratoServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
      
                    request.getRequestDispatcher("/cadastrar_contrato.jsp").forward(request, response);
                }
                break;
            // PROCURA CONTRATO
            case "find":
                {
                    try 
                    {
                        ManterContratoWebManager webManager = new ManterContratoWebManager ();
                        //System.out.println("TENTANDO MUITO");
                        webManager.findContrato (request, response);
                    } catch (SQLException | NamingException | SQLException_Exception | NegocioException_Exception | unioeste.geral.endereco.webservice.SQLException_Exception ex) {
                        Logger.getLogger(ManterContratoServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }  
                }
                break;
            default:
                break;
        }
    }
}
