package unioeste.geral.endereco.bean;

import java.sql.SQLException;
import javax.ejb.Stateful;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.manager.UCEnderecoGeralServicos;

@Stateful
public class MySistemaManterEnderecoSessionBean implements MySistemaManterEnderecoSessionBeanRemote 
{

    @Override
    public Endereco getEndereco(String string) throws SQLException 
    {
        UCEnderecoGeralServicos end = new UCEnderecoGeralServicos ();
        return end.getEndereco(string);
    }

    @Override
    public Boolean verificarCEP(String string) 
    {
        UCEnderecoGeralServicos end = new UCEnderecoGeralServicos ();
        return end.verificarCEP(string);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Endereco getEnderecoByID(int i) throws SQLException 
    {
        UCEnderecoGeralServicos end = new UCEnderecoGeralServicos ();
        return end.getEnderecoByID(i);        
    }
}
