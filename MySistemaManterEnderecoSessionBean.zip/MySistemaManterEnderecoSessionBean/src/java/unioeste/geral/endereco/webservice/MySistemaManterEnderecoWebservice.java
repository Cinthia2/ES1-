package unioeste.geral.endereco.webservice;

import java.sql.SQLException;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import unioeste.geral.endereco.bean.MySistemaManterEnderecoSessionBeanRemote;
import unioeste.geral.endereco.bo.Endereco;

@WebService(serviceName = "MySistemaManterEnderecoWebservice")
@Stateless()
public class MySistemaManterEnderecoWebservice 
{

    @EJB
    private MySistemaManterEnderecoSessionBeanRemote ejbRef;// Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Web Service Operation")

    @WebMethod(operationName = "getEndereco")
    public Endereco getEndereco(@WebParam(name = "string") String string) throws SQLException 
    {
        return ejbRef.getEndereco(string);
    }

    @WebMethod(operationName = "verificarCEP")
    public Boolean verificarCEP(@WebParam(name = "string") String string) 
    {
        return ejbRef.verificarCEP(string);
    }
    
    @WebMethod(operationName = "getEnderecoByID")
    public Endereco getEnderecoByID(@WebParam(name = "int") int i) throws SQLException 
    {
        return ejbRef.getEnderecoByID(i);
    }
    
}
