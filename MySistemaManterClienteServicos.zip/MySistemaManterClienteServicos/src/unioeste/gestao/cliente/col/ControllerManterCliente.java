package unioeste.gestao.cliente.col;

import java.sql.Connection;
import unioeste.gestao.cliente.dao.DaoManterCliente;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import java.sql.SQLException;

public class ControllerManterCliente 
{
    private Connection connection;
    
    public void setConnection (Connection connection)
    {
        this.connection = connection;
    }
    
    public Connection getConnection ()
    {
        return this.connection;
    }
    
    public Boolean CpfJaCadastrado (String CPF) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        String CPF2 = dao.verificarClienteByCPF(CPF);
        
        if (CPF2.isEmpty())
        {
            System.out.print("Cliente não cadastrado");
            return false;
        }
        else
            return true;        
    }
    
    public Boolean CnpjJaCadastrado (String CNPJ) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        String CNPJ2 = dao.verificarClienteByCNPJ(CNPJ);
        
        if (CNPJ2.isEmpty())
        {
            System.out.print("Cliente não cadastrado");
            return false;
        }
        else
            return true;        
    }
    
    public String procurarClienteCPFByID (int id) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        String cpf = dao.buscarCPFClienteById(id);
        if (cpf == null)
        {
            System.out.print("Cliente não cadastrado");
            return null;
        }
            return cpf;
    }
      
    public Cliente procurarClienteByCPF (String CPF) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        Cliente cliente = dao.getClienteByCPF(CPF);
        if (cliente == null)
        {
            System.out.print("Cliente não cadastrado");
            return null;
        }
            return cliente;
    }
    
    public Cliente procurarClienteByCNPJ (String CNPJ) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        Cliente cliente = dao.getClienteByCNPJ(CNPJ);
        if (cliente == null)
        {
            System.out.print("Cliente não cadastrado");
            return null;
        }
            return cliente;
    }
    
    public void cadastrarEmail (Cliente cliente) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        dao.inserirEmail(cliente);
    }
    
    public void cadastrarFone (Cliente cliente) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        dao.inserirTelefone(cliente);
    }
    
    public void cadastrarCliente (Cliente cliente) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        dao.inserirCliente(cliente);
    }
    
    public Cliente procurarClienteByID (int id) throws SQLException
    {
        DaoManterCliente dao = new DaoManterCliente (connection);
        return dao.procurarClienteByID (id);
    }
}
