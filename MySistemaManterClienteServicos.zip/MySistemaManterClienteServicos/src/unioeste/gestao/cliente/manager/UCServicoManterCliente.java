package unioeste.gestao.cliente.manager;

import java.sql.Connection;
import unioeste.apoio.verificacao.Verificacao;
import java.util.List;
import java.util.Map;
import unioeste.gestao.cliente.col.ControllerManterCliente;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import java.sql.SQLException;
import unioeste.apoio.BD.ConexaoBanco;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.pessoa.bo.*;

public class UCServicoManterCliente
{
    private Connection conexaoBD;
    
    public void startConexaoBD () throws SQLException
    {
        System.out.println("entrou ctr cliente");
        //ConexaoBanco bd = new ConexaoBanco ();
        conexaoBD = ConexaoBanco.getConnection(); 
    }
    
    public void closeConexaoBD () throws SQLException
    {
        conexaoBD.close();
    }
    
    public Boolean verificarCEP (String cep)
    {
        Endereco endVerificacao = new Endereco ();
        return endVerificacao.verificarCEP(cep);
    }
    
    // move to cliente class
    public Boolean verificarCPF (String cpf, Map <String, String> messages)
    {
        Verificacao verify = new Verificacao ();
        return verify.verificarCPF(cpf, messages);
    }
     
    // move to cliente class
    public Boolean verificarDados (List <String> dados, Map <String, String> messages)           
    {
        Verificacao verify = new Verificacao ();
        return (verify.verificarDados(dados, messages) == 9);
    }       
    
    public Cliente consultarCliente (String CPFouCNPJ) throws SQLException
    {
        this.startConexaoBD();
        //System.out.println("ola4");
        
        ControllerManterCliente controllerCliente = new ControllerManterCliente ();
        controllerCliente.setConnection(conexaoBD);
        
        PessoaFisica fis = new PessoaFisica();
        
        Cliente cliente;
        
        if (fis.ehCpf(CPFouCNPJ))
        {
            //System.out.println("ola5");
            cliente = controllerCliente.procurarClienteByCPF(CPFouCNPJ);
            
            this.closeConexaoBD();
            
            if (cliente == null)
                return null;
            return cliente;
        }
        else
        {
            //System.out.println("ola6");
            if (!fis.verificarCaracteresNumericos(CPFouCNPJ))
            {
                cliente = controllerCliente.procurarClienteByCNPJ(CPFouCNPJ); 
                
                this.closeConexaoBD();
                
                    if (cliente == null)
                        return null;
                return cliente;
            }
        }
        //System.out.println("ola7");
        return null;
    }
    
    public Boolean clienteExiste (String CPF) throws SQLException
    {
        //this.startConexaoBD();
        
        ControllerManterCliente ctrl = new ControllerManterCliente ();
        //System.out.println("entrou");
        ctrl.setConnection(conexaoBD);
        //this.closeConexaoBD();
        
        return ctrl.CpfJaCadastrado(CPF);
    }
    
    public Boolean clienteExisteByCPF (String CPF) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterCliente ctrl = new ControllerManterCliente ();
        //System.out.println("entrou");
        ctrl.setConnection(conexaoBD);
        
        Boolean a = ctrl.CpfJaCadastrado(CPF);
        
        this.closeConexaoBD();

        return a;
    }
        
    public Boolean clienteExisteByCNPJ (String CNPJ) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterCliente ctrl = new ControllerManterCliente ();
        //System.out.println("entrou");
        ctrl.setConnection(conexaoBD);
        
        Boolean a = ctrl.CnpjJaCadastrado(CNPJ);
        
        this.closeConexaoBD();
        
        return a;
    }    
    
    public Cliente cadastrarCliente (Cliente cliente) throws SQLException, NegocioException
    {
        this.startConexaoBD();
        
        Verificacao verify = new Verificacao ();
        
        if (cliente.getDadosCliente() instanceof PessoaFisica)
        {
            PessoaFisica fis = (PessoaFisica) cliente.getDadosCliente();
            if (clienteExisteByCPF (fis.getCPF()))
            {
                throw new NegocioException ("CPF já cadastrado no sistema.");
            }
            
            if (!verify.verificarCPF(fis.getCPF()))
            {
                throw new NegocioException ("CPF com tamanho e/ou caracteres inválidos.");
            }  
            
            if (!verify.verificarSexo(fis.getSexo().getSigla()))
            {
                throw new NegocioException ("Sexo incorreto.");
            }            
            
        }
        else
        {
            PessoaJuridica jur = (PessoaJuridica) cliente.getDadosCliente();
            if (clienteExisteByCNPJ(jur.getCNPJ()))
            {
                throw new NegocioException ("CNPJ já cadastrado no sistema.");
            }
            
            if (!verify.verificarNome(jur.getNomeFantasia()))
            {
                throw new NegocioException ("Nome fantasia inválido/fora do padrão.");
            }            
        }
        
        if (!verify.verificarNome(cliente.getDadosCliente().getNome()))
        {
            throw new NegocioException ("Nome inválido/fora do padrão.");
        }

        if (!verify.verificarTelefone(cliente.getDadosCliente().getFone().get(0).getNumero()))
        {
            throw new NegocioException ("Número de telefone com caracteres/tamanho inválido.");
        }
        
        /*if (!enderecoExiste (cliente.getDadosCliente().getEnderecoEspecifico().getEndereco()))
        {
            throw new NegocioException ("Endereco não cadastradado.");
        }*/
        
        
        ControllerManterCliente controllerCliente = new ControllerManterCliente ();
        controllerCliente.setConnection(conexaoBD);
        
        controllerCliente.cadastrarCliente(cliente);
        
        controllerCliente.cadastrarFone(cliente);
        
        controllerCliente.cadastrarEmail(cliente);
        
        this.closeConexaoBD();
        
        return cliente;
    }
    
    /*public boolean enderecoExiste (Endereco endereco) throws SQLException
    {
        UCMySistemaManterEnderecoRemote ctrlServicos = new UCMySistemaManterEnderecoRemote ();
        
        Endereco clienteEndereco = ctrlServicos.getSessionBean().getEndereco (endereco.getCEP());

        if (clienteEndereco != null)
        {

            return (clienteEndereco.getId() == endereco.getId());
        }
        else
        {
           return false;
        }       
    }*/
    
    public Boolean clienteExiste (String CPF, Map<String, String> messages) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterCliente ctrl = new ControllerManterCliente ();
        ctrl.setConnection(conexaoBD);
        
        if (!ctrl.CpfJaCadastrado(CPF))
        {
            messages.put("errorcliente", "Cliente com este CPF não cadastrado no sistema.");
            this.closeConexaoBD();
            return false;
        }
        this.closeConexaoBD();
        return true;
    }
    
    public String buscaCPFByID(int id ) throws SQLException{ 
      this.startConexaoBD();
         System.out.println("ola2");
         ControllerManterCliente ctrl = new ControllerManterCliente ();
          ctrl.setConnection(conexaoBD);
         ctrl.procurarClienteCPFByID(id);
        
        this.closeConexaoBD();
       return ctrl.procurarClienteCPFByID(id);
        
    }
    
    public Cliente procurarClienteByID (int id) throws SQLException
    {
        this.startConexaoBD();
        
        ControllerManterCliente ctrl = new ControllerManterCliente ();       
        ctrl.setConnection(conexaoBD);
        
        Cliente cliente = ctrl.procurarClienteByID (id);
        
        this.closeConexaoBD();
                
        return cliente;
    }
    
}
