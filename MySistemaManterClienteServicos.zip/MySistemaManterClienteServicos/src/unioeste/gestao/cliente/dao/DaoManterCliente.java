package unioeste.gestao.cliente.dao;

import unioeste.geral.endereco.bo.*;
import unioeste.geral.pessoa.bo.*;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoManterCliente 
{
    private Connection connection;
    
    public DaoManterCliente (Connection connection)
    {
        this.connection = connection;
    }
    
    public String verificarClienteByCPF (String CPF) throws SQLException
    {
        String sql = "SELECT cliente.cpf FROM cliente WHERE cpf = '" + CPF + "';";
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        String cpf2 = "";
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cpf2 = rs.getString("cpf");
                
            }
        }
        stmt.close(); 
        
        return cpf2;
    }
    
        public String verificarClienteByCNPJ (String CNPJ) throws SQLException
    {
        String sql = "SELECT * FROM cliente WHERE cnpj = '" + CNPJ + "';";
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        String cpf2 = "";
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cpf2 = rs.getString("cnpj");                
            }
        }
        stmt.close(); 
        
        return cpf2;
    }
    
    public Cliente getClienteByCPF (String CPF) throws SQLException
    {  
        String sql = "SELECT p.idcliente, p.nomecliente, p.numerologradouro, "
                + "p.complemento, p.cpf, p.idendereco, "
                + "p.idsexo, p.datanascimento, x.sexo, "
                + "t.idtelefone, t.telefone, t.idddd, d.ddd, d.idddi, i.ddi, e.idemail, e.email "
                + "FROM cliente p LEFT JOIN sexo x ON x.idsexo = p.idsexo "
                + "LEFT JOIN telefonecliente t ON t.idcliente = p.idcliente "
                + "LEFT JOIN ddd d ON d.idddd = t.idddd LEFT JOIN ddi i ON "
                + "i.idddi = d.idddi LEFT JOIN emailcliente e ON e.idcliente = "
                + "p.idcliente WHERE p.cpf = '" + CPF + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Cliente cliente = new Cliente();
        
        PessoaFisica fis = new PessoaFisica();
        
        Sexo sexo = new Sexo ();
        
        List<Email> emailist = new ArrayList <>();
        Email email = new Email ();
        
        List<Telefone> telist = new ArrayList <>();
        Telefone telefone = new Telefone ();
        DDD ddd = new DDD ();
        DDI ddi = new DDI ();
        
        Endereco end = new Endereco();
        EnderecoEspecifico ee = new EnderecoEspecifico ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {               
                email.setId(rs.getInt("idemail"));
                email.setEmail(rs.getString("email"));
                emailist.add(email);
                fis.setEmail(emailist);
                
                ddi.setDDI(rs.getString("ddi"));
                ddi.setIdDDI(rs.getInt("idddi"));
                telefone.setDdi(ddi);
                
                ddd.setId(rs.getInt("idddd"));
                ddd.setNumero(rs.getString("ddd"));
                telefone.setDdd(ddd);
                
                telefone.setId(rs.getInt("idtelefone"));
                telefone.setNumero(rs.getString("telefone"));
                telist.add(telefone);
                fis.setFone(telist);
                
                sexo.setId(rs.getInt("idsexo"));
                sexo.setSigla(rs.getString("sexo"));
                fis.setSexo(sexo);
                
                end.setId(rs.getInt("idendereco"));
                ee.setEndereco(end);
                
                ee.setComplemento(rs.getString("complemento"));
                ee.setNumero(rs.getString("numerologradouro"));
                fis.setEnderecoEspecifico(ee);
                
                fis.setDataNascimento(rs.getString("datanascimento"));
                fis.setNome(rs.getString("nomecliente"));
                fis.setCPF(rs.getString("cpf"));
                
                cliente.setDadosCliente(fis);
                cliente.setIdCliente(rs.getInt("idcliente"));
            }
        }
        stmt.close();
        return cliente;    
    }
    
        public Cliente getClienteByCNPJ (String CNPJ) throws SQLException
    {  
        String sql = "SELECT p.idcliente, p.nomecliente, p.numerologradouro, "
                + "p.complemento, p.cnpj, p.nomefantasia, p.idendereco, "
                + "t.idtelefone, t.telefone, t.idddd, d.ddd, d.idddi, i.ddi, e.idemail, e.email "
                + "FROM cliente p LEFT JOIN telefonecliente t ON t.idcliente = p.idcliente "
                + "LEFT JOIN ddd d ON d.idddd = t.idddd LEFT JOIN ddi i ON "
                + "i.idddi = d.idddi LEFT JOIN emailcliente e ON e.idcliente = "
                + "p.idcliente WHERE p.cpf = '" + CNPJ + "';";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Cliente cliente = new Cliente();
        
        PessoaJuridica jus = new PessoaJuridica ();
        
        List<Email> emailist = new ArrayList <>();
        Email email = new Email ();
        
        List<Telefone> telist = new ArrayList <>();
        Telefone telefone = new Telefone ();
        DDD ddd = new DDD ();
        DDI ddi = new DDI ();
        
        Endereco end = new Endereco();
        EnderecoEspecifico ee = new EnderecoEspecifico ();
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {               
                email.setId(rs.getInt("idemail"));
                email.setEmail(rs.getString("email"));
                emailist.add(email);
                jus.setEmail(emailist);
                
                ddi.setDDI(rs.getString("ddi"));
                ddi.setIdDDI(rs.getInt("idddi"));
                telefone.setDdi(ddi);
                
                ddd.setId(rs.getInt("idddd"));
                ddd.setNumero(rs.getString("ddd"));
                telefone.setDdd(ddd);
                
                telefone.setId(rs.getInt("idtelefone"));
                telefone.setNumero(rs.getString("telefone"));
                telist.add(telefone);
                jus.setFone(telist);
                
                end.setId(rs.getInt("idendereco"));
                ee.setEndereco(end);
                
                ee.setComplemento(rs.getString("complemeto"));
                ee.setNumero(rs.getString("numerologradouro"));
                jus.setEnderecoEspecifico(ee);
               
                jus.setNome(rs.getString("nomecliente"));
                jus.setNomeFantasia(rs.getString("nomefantasia"));
                jus.setCNPJ(rs.getString("cnpj"));
               
                
                cliente.setDadosCliente(jus);
                cliente.setIdCliente(rs.getInt("idcliente"));
            }
        }
        stmt.close();
        return cliente;    
    }
    
    public void inserirTelefone (Cliente cliente) throws SQLException
    {
        String sql = "INSERT INTO telefonecliente (telefone, idddd, idcliente) "
                + "VALUES ('" + cliente.getDadosCliente().getFone().get(0).getNumero() + 
                "', " + cliente.getDadosCliente().getFone().get(0).getDdd().getId() + 
                "', " + cliente.getIdCliente()+ ");";
        
        PreparedStatement stmt;
        
        stmt = connection.prepareStatement (sql);
        
        stmt.executeUpdate();
        
        stmt.close();          
    }
    
    public void inserirEmail (Cliente cliente) throws SQLException
    {
        String sql = "INSERT INTO email (email, idcliente) VALUES "
                + "('" + cliente.getDadosCliente().getEmail().get(0).getEmail() + 
                "', " + cliente.getIdCliente() + "');";
        
        PreparedStatement stmt;
        
        stmt = connection.prepareStatement (sql);
        
        stmt.executeUpdate();
        
        stmt.close();         
    }
    
    public void inserirCliente (Cliente cliente) throws SQLException
    {
        PessoaFisica fis;
        PessoaJuridica jur;
        String sql;
        
        if (cliente.getDadosCliente() instanceof PessoaFisica)
        {
            fis = (PessoaFisica)cliente.getDadosCliente();
            sql = "INSERT INTO cliente (nomecliente, numerologradouro, complemento, "
                    + "cpf, idendereco, idsexo, datanascimento) VALUES "
                    + "('" + fis.getNome() + "', '" + fis.getEnderecoEspecifico().getNumero() + 
                    "', '" + fis.getEnderecoEspecifico().getComplemento() + "', '" + fis.getCPF() + 
                    "', " + fis.getEnderecoEspecifico().getEndereco().getId() + 
                    ", " + fis.getSexo().getId() + ", '" + fis.getDataNascimento() + "') RETURNING idcliente;";
            
            PreparedStatement stmt;
            
            stmt = connection.prepareStatement (sql);
        
            try (ResultSet rs = (ResultSet) stmt.executeQuery ())
            {
                while (rs.next())
                {
                    cliente.setIdCliente(rs.getInt("idcliente"));
                }
            }

            stmt.close(); 
        }
        else
        {
            jur =  (PessoaJuridica)cliente.getDadosCliente();  
            
            sql = "INSERT INTO cliente (nomecliente, numerologradouro, "
                    + "complemento, cnpj, nomefantasia, idendereco) "
                    + "VALUES ('" + jur.getNome() + "', '" + jur.getEnderecoEspecifico().getNumero() + "', '" 
                    + jur.getEnderecoEspecifico().getComplemento() + "', '" + jur.getCNPJ() + "', '" 
                    + jur.getNomeFantasia() + "', " + jur.getEnderecoEspecifico().getEndereco().getId() + ") RETURNING idcliente;";
            
            PreparedStatement stmt;
            
            stmt = connection.prepareStatement (sql);
        
            try (ResultSet rs = (ResultSet) stmt.executeQuery ())
            {
                while (rs.next())
                {
                    cliente.setIdCliente(rs.getInt("idcliente"));
                }
            }

            stmt.close(); 
        }          
    }
    
    public String buscarCPFClienteById (int id ) throws SQLException
    {
        String sql = "SELECT cpf FROM cliente WHERE id = '" + id + "';";
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        String cpf = null;
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                cpf = rs.getString("cpf");
            }
        }
        stmt.close(); 
        
        return cpf;
    }
    
    public Cliente procurarClienteByID (int id) throws SQLException
    {
        String sql = "SELECT c.idcliente, c.nomecliente, c.numerologradouro, "
                + "c.complemento, c.cpf, c.cnpj, c.nomefantasia, c.idendereco, "
                + "c.idsexo, c.datanascimento, x.sexo, e.idemail, e.email, "
                + "t.idtelefone, t.telefone, t.idddd, d.ddd, d.idddi, i.ddi "
                + "FROM cliente c LEFT JOIN sexo x ON x.idsexo = c.idsexo "
                + "LEFT JOIN emailcliente e ON e.idcliente = c.idcliente "
                + "LEFT JOIN telefonecliente t ON t.idcliente = c.idcliente "
                + "LEFT JOIN ddd d ON d.idddd = t.idddd LEFT JOIN ddi i ON "
                + "i.idddi = d.idddi WHERE c.idcliente = " + id + ";";
        
        PreparedStatement stmt;
        stmt = connection.prepareStatement (sql);
        
        Cliente cliente = new Cliente ();
        EnderecoEspecifico endEsp = new EnderecoEspecifico();
        Endereco end = new Endereco ();
        Sexo sexo = new Sexo();
        
        DDD ddd = new DDD();
        DDI ddi = new DDI();
        List<Telefone> telist = new ArrayList<>();
        Telefone tel = new Telefone ();
        
        List<Email> emailist = new ArrayList<>();
        Email email = new Email ();
        
        String cnpj = "";
        
        try (ResultSet rs = (ResultSet) stmt.executeQuery ())
        {
            while (rs.next())
            {
                email.setId(rs.getInt("idemail"));
                email.setEmail(rs.getString("email"));
                emailist.add(email);
                
                ddi.setIdDDI(rs.getInt("idddi"));
                ddi.setDDI(rs.getString("ddi"));
                
                ddd.setId(rs.getInt ("idddd"));
                ddd.setNumero(rs.getString("ddd"));
                
                tel.setDdd(ddd);
                tel.setDdi(ddi);
                tel.setId(rs.getInt("idtelefone"));
                tel.setNumero(rs.getString("telefone"));
                telist.add(tel);
                
                end.setId(rs.getInt("idendereco"));
                endEsp.setEndereco(end);
                
                endEsp.setComplemento(rs.getString("complemento"));
                endEsp.setNumero(rs.getString("numerologradouro"));
                
                cnpj = rs.getString("cnpj");
                
                if (cnpj == null)
                {
                    
                    PessoaFisica fis = new PessoaFisica ();
                    
                    fis.setEmail(emailist);
                    fis.setFone(telist);
                    
                    fis.setCPF(rs.getString("cpf"));
                    fis.setDataNascimento(rs.getString("datanascimento"));
                    fis.setNome(rs.getString("nomecliente"));
                    
                    fis.setEnderecoEspecifico(endEsp);
                    
                    sexo.setId(rs.getInt("idsexo"));
                    sexo.setSigla(rs.getString("sexo"));
                    fis.setSexo(sexo);
                    
                    cliente.setDadosCliente(fis);
                }
                else
                {
                    PessoaJuridica jur = new PessoaJuridica();
                    
                    jur.setEmail(emailist);
                    jur.setFone(telist);
                    
                    
                    jur.setCNPJ(rs.getString("cnpj"));
                    jur.setNome(rs.getString("nomecliente"));
                    jur.setNomeFantasia(rs.getString("nomefantasia"));
                    
                    jur.setEnderecoEspecifico(endEsp);
                    
                    cliente.setDadosCliente(jur);
                }

                cliente.setIdCliente(rs.getInt("idcliente"));
            }
        }
        stmt.close(); 

        return cliente;
    }
    
}
