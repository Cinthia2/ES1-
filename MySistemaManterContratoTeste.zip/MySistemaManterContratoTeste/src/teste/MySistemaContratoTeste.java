package teste;

import java.sql.SQLException;
import javax.naming.NamingException;
import unioeste.apoio.exceptions.NegocioException;
import unioeste.geral.endereco.bo.Endereco;
import unioeste.geral.endereco.manager.UCMySistemaManterEnderecoRemote;
import unioeste.geral.pessoa.bo.PessoaFisica;
import unioeste.gestao.cliente.manager.UCServicoManterCliente;
import unioeste.gestao.contrato.manager.UCMySistemaManterContratoRemote;
import unioeste.gestao.empresa.cliente.bo.Cliente;
import unioeste.gestao.empresa.contrato.bo.*;

public class MySistemaContratoTeste 
{
    public static void main(String[] args) throws NamingException, SQLException, NegocioException
    {
        
        
        //getDados("156023457895274152424000001");
        
        //setDados ();
        
        getDados ("123456");
    }
    
    public static void getDados (String numero) throws NamingException, SQLException, NegocioException
    {
        UCMySistemaManterContratoRemote servico = new UCMySistemaManterContratoRemote();
        Contrato contrato;
        contrato = servico.getSessionBean().ConsultarContratoPorNumero(numero);
        
        System.out.println("------------------------------------------------------------------------");
        System.out.println("Número: " + contrato.getNumeroContrato());
        System.out.println("Data emissão: " + contrato.getDataEmissao());
        System.out.println("Tipo contrato: " + contrato.getTipoContrato().getNome());
        System.out.println("Início: " + contrato.getPeriodo().getDataInicial() 
                + " Fim: " + contrato.getPeriodo().getDataFinal());
        System.out.println("Descrição: " + contrato.getDescricao());
        System.out.println("Valor: R$ " + contrato.getValorContrato());
        System.out.println("------------------------------------------------------------------------");
        
        UCServicoManterCliente servicoCliente = new UCServicoManterCliente ();
        Cliente cliente;
        
        if ((cliente = servicoCliente.procurarClienteByID(contrato.getCliente().getIdCliente())) != null)
        //if ((cliente = contrato.getCliente()) != null)
        {
            PessoaFisica fis = (PessoaFisica)cliente.getDadosCliente();

            System.out.println("-----------------------------------------------------------------------------"); 
            System.out.println("Nome: " + fis.getNome());
            System.out.println("Data nascimento: " + fis.getDataNascimento());              
            System.out.println("CPF: " + fis.getCPF());
            System.out.println("Sexo: " + fis.getSexo().getSigla());
            System.out.println("Email(s): " + fis.getEmail().get(0).getEmail());
            System.out.println("Telefone(s): " + fis.getFone().get(0).getDdi().getDDI() 
                    + " " + fis.getFone().get(0).getDdd().getNumero() 
                    + " " + fis.getFone().get(0).getNumero());
            System.out.println("-----------------------------------------------------------------------------");
            
            String CEP = "85851020";
            Endereco end;
            
            UCMySistemaManterEnderecoRemote serviceEndereco = new UCMySistemaManterEnderecoRemote ();
            
            //if ((end = fis.getEnderecoEspecifico().getEndereco()) != null)
            if((end = serviceEndereco.getSessionBean().getEnderecoByID(1)) != null)
            {
                System.out.println(end.getCidade().getNome());
                System.out.println(end.getBairro().getNome());
                System.out.println(end.getRua().getNome());
                System.out.println(end.getCidade().getEstado().getNome());
            } 
        }        
    }
    
    public static void setDados () throws NamingException, SQLException, NegocioException
    {
        Contrato contrato = new Contrato ();
        TipoContrato tipo = new TipoContrato ();
        PeriodoContrato periodo = new PeriodoContrato ();
        Cliente cliente = new Cliente ();
        PessoaFisica fis = new PessoaFisica();
        
        contrato.setDataEmissao("25-10-2018");
        contrato.setDescricao("testudo");
        contrato.setNumeroContrato("123456");
        contrato.setValorContrato(250.51);
        
        tipo.setId(1);
        contrato.setTipoContrato(tipo);
        
        periodo.setDataInicial("01-01-2019");
        periodo.setDataFinal("02-02-2019");
        contrato.setPeriodo(periodo);
        
        fis.setCPF("98765432100");
        cliente.setDadosCliente(fis);
        
        cliente.setIdCliente(1);
        contrato.setCliente(cliente);  
        
        UCMySistemaManterContratoRemote servico = new UCMySistemaManterContratoRemote();
        servico.getSessionBean().cadastrarContrato(contrato);
    }
}
