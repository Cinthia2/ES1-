package unioeste.gestao.empresa.contrato.bo;

import java.io.Serializable;
import java.util.Map;
import java.util.Objects;
import unioeste.gestao.empresa.cliente.bo.Cliente;

public class Contrato implements Serializable
{
    private int idContrato; 
    private  String dataEmissao; 
    private TipoContrato tipoContrato;
    private PeriodoContrato periodo;
    private String numeroContrato; 
    private String descricao;
    private double valorContrato;
    private Cliente cliente;

    public int getIdContrato() 
    {
        return idContrato;
    }

    public void setIdContrato(int idContrato) 
    {
        this.idContrato = idContrato;
    }

    public String getDataEmissao() 
    {
        return dataEmissao;
    }

    public void setDataEmissao(String dataEmissao) 
    {
        this.dataEmissao = dataEmissao;
    }

    public TipoContrato getTipoContrato() 
    {
        return tipoContrato;
    }

    public void setTipoContrato(TipoContrato tipoContrato) 
    {
        this.tipoContrato = tipoContrato;
    }

    public String getNumeroContrato() 
    {
        return numeroContrato;
    }

    public void setNumeroContrato(String numeroContrato) 
    {
        this.numeroContrato = numeroContrato;
    }

    public String getDescricao() 
    {
        return descricao;
    }

    public void setDescricao(String descricao) 
    {
        this.descricao = descricao;
    }

    public double getValorContrato() 
    {
        return valorContrato;
    }

    public void setValorContrato(double valorContrato) 
    {
        this.valorContrato = valorContrato;
    }

    public PeriodoContrato getPeriodo() 
    {
        return periodo;
    }

    public void setPeriodo(PeriodoContrato periodo) 
    {
        this.periodo = periodo;
    }

    public Cliente getCliente() 
    {
        return cliente;
    }

    public void setCliente(Cliente cliente) 
    {
        this.cliente = cliente;
    }
    
    public Boolean verificarData (String data, Map <String, String> messages)
    {
        System.out.println("Data: " + (data.length() == 10));
        if (!(data.length() == 10))
        {
            messages.put ("errordata", "Data inválida ou incompátivel com o CPF adicionado.");
            return false;          
        }
        return true;
    }
    
    public Boolean verificarData (String data)
    {
        if (!(data.length() == 10))
        {
            return false;
        }
        else
        {
            String[] datasplit;
            datasplit = data.split("-");
            
            for (int i = 0; i < 2; i++)
            {
                if (!(verificarCaracteresNumericos(datasplit[i])))
                    return false;
            }
            
            return (verificarDia(datasplit[0]) && verificarMes(datasplit[1]) && verificarAno(datasplit[2]));
        }
    }
    
    public Boolean verificarDia (String dia)
    {
        int day = Integer.valueOf(dia);
        return (day > 0 && day < 32);
    }
    
    public Boolean verificarMes (String mes)
    {
        int month = Integer.valueOf(mes);
        return (month > 0 && month < 13);
    }
    
    public Boolean verificarAno (String ano)
    {
        int year = Integer.valueOf(ano);
        return (year > 1950 && year < 2070);
    }
    
    public Boolean verificarCaracteresNumericos(String target)
    {
        return target.matches("^[0-9]*$");
    }
    
    public Boolean verificarNumeroContrato(String numero)
    {
        return verificarCaracteresNumericos (numero);
    }
    
    public Boolean validarDatas (String dataInicial, String dataFinal)
    {
        String[] datasplit1, datasplit2;
        datasplit1 = dataInicial.split("-");
        datasplit2 = dataFinal.split("-");
       
        if (Integer.valueOf(datasplit2[2]) < Integer.valueOf(datasplit1[2]))
        {
            return false;
        }
        
        if (Objects.equals(Integer.valueOf(datasplit2[2]), Integer.valueOf(datasplit1[2])))
        {
            if (Integer.valueOf(datasplit2[1]) < Integer.valueOf(datasplit1[1]))
                return false;
        }
        
        if (Objects.equals(Integer.valueOf(datasplit2[2]), Integer.valueOf(datasplit1[2])))
        {
            if (Objects.equals(Integer.valueOf(datasplit2[1]), Integer.valueOf(datasplit1[1])))
            {
                if (Integer.valueOf(datasplit2[0]) < Integer.valueOf(datasplit1[0]))
                    return false;
            }           
        } 
       
        return true;
        
    }
    
    public Boolean verificarValorContrato (double valor)
    {
        return (valor >= 1.0f);
    }

}
