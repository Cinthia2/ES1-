package unioeste.gestao.empresa.contrato.bo;

import java.io.Serializable;

public class PeriodoContrato implements Serializable
{
    private String dataInicial;
    private String dataFinal;

    public String getDataInicial() 
    {
        return dataInicial;
    }

    public void setDataInicial(String dataInicial) 
    {
        this.dataInicial = dataInicial;
    }

    public String getDataFinal() 
    {
        return dataFinal;
    }

    public void setDataFinal(String dataFinal) 
    {
        this.dataFinal = dataFinal;
    }
   
}
